# Multi-Environment Guide — Single AKS, Namespaces for Dev/Test/Prod

```
Azure Subscription
       │
 Resource Group
       │
┌──────────────────────────────────────────────────────┐
│                AKS Cluster (Single)                   │
│                                                        │
│  ┌────────────┐   ┌────────────┐   ┌────────────┐     │
│  │ retail-dev │   │ retail-test│   │ retail-prod│     │
│  │ Namespace  │   │ Namespace  │   │ Namespace  │     │
│  └─────┬──────┘   └─────┬──────┘   └─────┬──────┘     │
│        │                │                │            │
│  SparkApplication  SparkApplication  SparkApplication  │
│        │                │                │            │
│  Driver/Executors  Driver/Executors  Driver/Executors  │
└────────┼────────────────┼────────────────┼─────────────┘
         ▼                ▼                ▼
   Workload Identity  Workload Identity  Workload Identity
         │                │                │
   ┌─────┴─────┐    ┌─────┴─────┐    ┌─────┴─────┐
   │  KV-dev    │    │  KV-test  │    │  KV-prod  │
   │  ST-dev    │    │  ST-test  │    │  ST-prod  │
   └───────────┘    └───────────┘    └───────────┘
```

This is exactly your diagram, made concrete: one AKS cluster, one control
plane, one node pool bill for the shared parts — but each namespace gets its
own storage, its own secrets, its own identity, and (for prod) its own
compute.

---

## 1. What's actually inside the AKS cluster

Run `terraform apply`, then look at what exists:

```bash
terraform output -raw aks_get_credentials_command | bash

kubectl get nodes                    # the shared system node pool (+ npprod if enabled)
kubectl get namespaces                # retail-dev, retail-test, retail-prod, plus kube-system etc.
kubectl get resourcequota -A          # one per environment, different numbers
kubectl get networkpolicy -A          # one per environment
kubectl get serviceaccount -n retail-dev spark-driver -o yaml   # the workload-identity annotation
```

**One cluster contains, from Terraform's perspective:**
| Object | Created by | Scope |
|---|---|---|
| The AKS control plane + node pool(s) | `main.tf` (`azurerm_kubernetes_cluster`, optionally `azurerm_kubernetes_cluster_node_pool.env["prod"]`) | Cluster-wide |
| ACR + AcrPull role assignment | `main.tf` | Cluster-wide - **any** namespace can pull from this one registry; there's no per-namespace image isolation unless you add per-env `imagePullSecrets`, which this lab doesn't need since ACR integration is at the kubelet level |
| Namespace `retail-<env>` | `environments.tf` (`kubernetes_namespace.env`) | Per environment |
| ResourceQuota | `environments.tf` (`kubernetes_resource_quota.env`) | Per environment |
| NetworkPolicy | `environments.tf` (`kubernetes_network_policy_v1.isolate`) | Per environment |
| ServiceAccount `spark-driver` | `environments.tf` (`kubernetes_service_account.spark_driver`) | Per environment |
| Managed Identity + federated credential | `environments.tf` | Per environment, 1:1 with the ServiceAccount above |
| Storage Account (ADLS Gen2) | `environments.tf` | Per environment |
| Key Vault | `environments.tf` | Per environment |
| Dedicated node pool (`npprod`) | `environments.tf`, gated by `enable_dedicated_node_pool` | Prod only, by default |

---

## 2. How `retail-dev` actually differs from `retail-test`/`retail-prod`

A Kubernetes **namespace by itself** is just a name scope — it does *not*
automatically isolate CPU, network traffic, or credentials. Everything that
makes dev/test/prod actually behave differently is a **separate object
Terraform attaches to that namespace**:

| Isolation dimension | Mechanism | Where in this repo |
|---|---|---|
| "Can this namespace exhaust cluster resources?" | `ResourceQuota` — dev capped at 4 CPU/8Gi/10 pods, prod at 32 CPU/64Gi/50 pods | `kubernetes_resource_quota.env[each.key]`, values from `environment_settings` |
| "Can a pod in dev talk to a pod in prod?" | `NetworkPolicy` restricting ingress to same-namespace + kube-system only | `kubernetes_network_policy_v1.isolate` |
| "Can dev's Spark job read prod's data?" | Each environment's Managed Identity has RBAC (`Storage Blob Data Contributor`) scoped to **only its own** Storage Account | `azurerm_role_assignment.env_storage_contributor` — the `scope` is `azurerm_storage_account.env[each.key].id`, not a shared account |
| "Can dev's Spark job read prod's secrets?" | Same pattern: `Key Vault Secrets User` scoped to only that environment's own Key Vault | `azurerm_role_assignment.env_kv_secrets_user` |
| "Can dev's pods land on prod's nodes?" | Optional dedicated node pool + taint `workload-env=prod:NoSchedule`; only pods with the matching toleration (see `k8s/overlays/prod/patch-sparkapplication.yaml`) schedule there | `azurerm_kubernetes_cluster_node_pool.env` |
| "Does the business logic change per environment?" | **No** — this is the whole point. The scoring rules, the SparkApplication CRD shape, the Docker image are identical across all three; only the four rows above change. | `k8s/base/sparkapplication.yaml` is byte-identical input into all three overlays |

So the honest answer to "how does namespace differ" is: **the namespace
name itself doesn't do the isolating — the ResourceQuota, NetworkPolicy, and
RBAC-scoped Managed Identity objects Terraform attaches to it do.** That's
also why this is safe to run as a single cluster instead of three: the
blast radius of a bug in the `retail-dev` namespace is bounded by these
objects, not by physical separation.

---

## 3. Deploying the Spark app into each namespace

You have **two independent ways to run the pipeline** on this cluster. Both work; pick whichever fits your workflow.

### Method A — plain `spark-submit`, no Spark Operator

`terraform output spark_submit_commands` prints one ready-to-run command per
environment (edit the image tag once you've pushed a real build):

```bash
terraform output -json spark_submit_commands | jq -r '.dev'
terraform output -json spark_submit_commands | jq -r '.test'
terraform output -json spark_submit_commands | jq -r '.prod'
```

Each expands to something like:

```bash
spark-submit --master k8s://<aks-fqdn>:443 \
  --deploy-mode cluster \
  --name retail-promotion-dev \
  --class com.retailbank.pipeline.PromotionPipeline \
  --conf spark.kubernetes.namespace=retail-dev \
  --conf spark.kubernetes.authenticate.driver.serviceAccountName=spark-driver \
  --conf spark.kubernetes.container.image=<acr-login-server>/retail-platform-promotion-model:demo-v1 \
  --conf spark.driver.extraJavaOptions=-Denv=dev \
  --conf spark.executor.extraJavaOptions=-Denv=dev \
  local:///opt/spark/jars/retail-platform-promotion-model-1.0.0.jar
```

Swap `retail-dev` → `retail-test` / `retail-prod`, `-Denv=dev` → `-Denv=test`
/ `-Denv=prod`, and nothing else — same jar, same image, three
environments. This only requires `kubectl` access and the `spark-submit`
binary locally; no Spark Operator needed.

**Prerequisite:** the ServiceAccount named in
`spark.kubernetes.authenticate.driver.serviceAccountName` needs an RBAC
Role/RoleBinding letting it create pods in its own namespace (Spark's
driver creates executor pods via the Kubernetes API). Grant it once per
environment:

```bash
for ENV in dev test prod; do
  kubectl create rolebinding spark-driver-edit \
    --clusterrole=edit \
    --serviceaccount=retail-$ENV:spark-driver \
    --namespace=retail-$ENV
done
```

### Method B — SparkApplication CRD + Kustomize (`k8s/`)

Install the Spark Operator once per cluster:
```bash
helm repo add spark-operator https://kubeflow.github.io/spark-operator
helm repo update
helm install spark-operator spark-operator/spark-operator \
  --namespace spark-operator --create-namespace --set webhook.enable=true
```

Then, per environment:
```bash
cd k8s/overlays/dev
kustomize edit set image CHANGE_ME_ACR_LOGIN_SERVER/retail-platform-promotion-model=$(terraform -chdir=../../.. output -raw acr_login_server)/retail-platform-promotion-model:demo-v1
cd ../../..
kubectl apply -k k8s/overlays/dev
kubectl get sparkapplications -n retail-dev
kubectl logs -n retail-dev -l spark-role=driver -f
```

Repeat for `test` and `prod` (prod's overlay additionally sets the
`workload-env=prod` toleration/nodeSelector so it lands on the dedicated
node pool). The difference between Method A and B is purely operational:
Method B gives you `kubectl get sparkapplications` status/restart-policy
management "for free"; Method A is simpler if you don't want to run an
extra operator.

---

## 4. How Key Vault is actually used (no secrets anywhere in Git or the image)

The chain, end to end:

1. **Terraform** creates a Managed Identity per environment (`azurerm_user_assigned_identity.env`) and a **federated credential**
   (`azurerm_federated_identity_credential.env`) trusting the AKS OIDC
   issuer to vouch for `system:serviceaccount:retail-<env>:spark-driver`.
2. **Terraform** also creates the `spark-driver` ServiceAccount itself,
   annotated with that identity's `client-id`
   (`kubernetes_service_account.spark_driver`).
3. When a driver pod using that ServiceAccount starts, AKS's **Workload
   Identity webhook** automatically:
   - projects a short-lived Kubernetes ServiceAccount token into the pod
   - sets `AZURE_CLIENT_ID`, `AZURE_TENANT_ID`,
     `AZURE_FEDERATED_TOKEN_FILE` environment variables into every
     container in that pod — **you don't set these yourself anywhere**
4. Inside the Java app, `DefaultAzureCredentialBuilder().build()` (in the
   Retail Platform Promotion Model's `AzureKeyVaultSecretsProvider`) sees
   those env vars, reads the projected token from
   `AZURE_FEDERATED_TOKEN_FILE`, and exchanges it with Azure AD for a real
   access token scoped to `https://vault.azure.net`.
5. `SecretClient.getSecret("promotion-downstream-api-key")` calls Key
   Vault with that token. Key Vault's RBAC (granted by
   `azurerm_role_assignment.env_kv_secrets_user`, scoped to *this
   environment's* vault only) authorizes the read.

No client secret, connection string, or API key is ever written to a
Kubernetes Secret, a config file, or the Docker image at any point in this
chain.

**Verifying it yourself, per environment:**
```bash
terraform output -json environment_key_vault_uris | jq -r '.dev'
# https://kv-dev-ab12c.vault.azure.net/

az keyvault secret show --vault-name kv-dev-ab12c --name promotion-downstream-api-key --query value -o tsv
# (this uses YOUR az login identity, via the Key Vault Secrets Officer role
#  Terraform granted your account - azurerm_role_assignment.env_kv_secrets_officer_deployer -
#  which is separate from the workload's own read-only Secrets User role)
```

Then confirm the *pod's* identity can read it too, by shelling into a
running driver pod (or checking its logs — the app already logs
`Resolved downstream API credential via provider='azure-keyvault(...)'` on
success).

**Set `secrets.key.vault.url` per environment** in the Java app's
`application-<env>.conf` from:
```bash
terraform output environment_key_vault_uris
terraform output environment_abfss_raw_paths
terraform output environment_abfss_curated_paths
```

---

## 5. Policy-whitelist risk (carried over from the original README)

Your subscription enforces `UnextAzurePolicy_AllowOnlyWhitelistedServices`.
The original config was already adjusted once (AKS `oms_agent` blocked).
**Key Vault, Storage Accounts, and Managed Identities are new resource
types this update introduces** and were *not* on the previously-verified
whitelist. Apply incrementally the first time so a policy rejection is easy
to isolate:

```bash
terraform apply -target=azurerm_user_assigned_identity.env
terraform apply -target=azurerm_storage_account.env
terraform apply -target=azurerm_key_vault.env
terraform apply   # everything else, including the namespaces/quotas/network policies
```

If any single `-target` apply fails with `RequestDisallowedByPolicy`, that
tells you exactly which resource type or SKU needs a whitelist exception
request — same diagnostic pattern the original README used for
`oms_agent`. Common levers if Key Vault's SKU is the blocker:
`environment_settings.<env>.key_vault_sku = "standard"` (already the
default here) is generally less restricted than `"premium"`.

---

## 6. Cleanup

```bash
kubectl delete -k k8s/overlays/dev    # if you deployed via Method B
kubectl delete -k k8s/overlays/test
kubectl delete -k k8s/overlays/prod
helm uninstall spark-operator -n spark-operator
terraform destroy
```

`terraform destroy` removes the namespaces, storage accounts, Key Vaults
(purged immediately - `purge_soft_delete_on_destroy = true` in
`providers.tf`), managed identities, and (if enabled) the dedicated node
pool, along with the shared cluster/VNet/ACR.
