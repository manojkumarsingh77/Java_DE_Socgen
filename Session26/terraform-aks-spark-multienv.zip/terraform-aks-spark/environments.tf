############################################
# Random suffix for globally-unique names (Storage Accounts, Key Vaults)
############################################
resource "random_string" "suffix" {
  length  = 5
  special = false
  upper   = false
  numeric = true
}

locals {
  name_suffix = coalesce(var.name_suffix_override, random_string.suffix.result)
}

############################################
# Per-environment: Storage Account (ADLS Gen2)
############################################
resource "azurerm_storage_account" "env" {
  for_each = var.environment_settings

  name                     = "st${each.key}retail${local.name_suffix}"
  resource_group_name      = azurerm_resource_group.this.name
  location                 = azurerm_resource_group.this.location
  account_tier             = each.value.storage_account_tier
  account_replication_type = each.value.storage_replication_type
  account_kind             = "StorageV2"
  is_hns_enabled           = true # hierarchical namespace = ADLS Gen2, required for abfss://

  tags = merge(var.tags, { environment = each.key })
}

resource "azurerm_storage_container" "raw" {
  for_each              = var.environment_settings
  name                  = "raw"
  storage_account_name  = azurerm_storage_account.env[each.key].name
  container_access_type = "private"
}

resource "azurerm_storage_container" "curated" {
  for_each              = var.environment_settings
  name                  = "curated"
  storage_account_name  = azurerm_storage_account.env[each.key].name
  container_access_type = "private"
}

############################################
# Per-environment: User Assigned Managed Identity
# This is the identity the Spark driver/executor pods in each namespace
# federate to via Workload Identity - see kubernetes_service_account below
# and azurerm_federated_identity_credential.
############################################
resource "azurerm_user_assigned_identity" "env" {
  for_each = var.environment_settings

  name                = "id-retail-${each.key}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  tags                = merge(var.tags, { environment = each.key })
}

# Grants that identity read/write on ITS OWN environment's storage account only -
# a dev pod's identity cannot touch test or prod storage, even if it somehow
# obtained the abfss:// path, because the RBAC scope below is per-storage-account.
resource "azurerm_role_assignment" "env_storage_contributor" {
  for_each = var.environment_settings

  scope                = azurerm_storage_account.env[each.key].id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_user_assigned_identity.env[each.key].principal_id
}

############################################
# Per-environment: Key Vault (RBAC-authorized, not access-policy)
############################################
resource "azurerm_key_vault" "env" {
  for_each = var.environment_settings

  name                       = "kv-${each.key}-${local.name_suffix}"
  resource_group_name        = azurerm_resource_group.this.name
  location                   = azurerm_resource_group.this.location
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = each.value.key_vault_sku
  enable_rbac_authorization  = true # modern model: role assignments below, no access_policy blocks
  purge_protection_enabled   = false # lab convenience - allows clean `terraform destroy`; enable in a real prod vault
  soft_delete_retention_days = 7

  tags = merge(var.tags, { environment = each.key })
}

# Lets the environment's managed identity READ secrets from ITS OWN vault only.
resource "azurerm_role_assignment" "env_kv_secrets_user" {
  for_each = var.environment_settings

  scope                = azurerm_key_vault.env[each.key].id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_user_assigned_identity.env[each.key].principal_id
}

# Lets YOU (the identity Terraform is running as) write the demo secret in
# during apply - separate from the read-only role granted to the workload above.
resource "azurerm_role_assignment" "env_kv_secrets_officer_deployer" {
  for_each = var.environment_settings

  scope                = azurerm_key_vault.env[each.key].id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_key_vault_secret" "downstream_api_key" {
  for_each = var.environment_settings

  name         = "promotion-downstream-api-key"
  value        = var.downstream_api_key_secret_value
  key_vault_id = azurerm_key_vault.env[each.key].id

  depends_on = [azurerm_role_assignment.env_kv_secrets_officer_deployer]
}

data "azurerm_client_config" "current" {}

############################################
# Per-environment: Federated Identity Credential
# Trusts the AKS cluster's OIDC issuer to vouch for a specific Kubernetes
# ServiceAccount, so that ServiceAccount's projected token can be exchanged
# for an Azure AD token for the matching Managed Identity above - with no
# client secret, anywhere, ever.
############################################
resource "azurerm_federated_identity_credential" "env" {
  for_each = var.environment_settings

  name                = "fed-retail-${each.key}"
  resource_group_name = azurerm_resource_group.this.name
  parent_id           = azurerm_user_assigned_identity.env[each.key].id
  audience            = ["api://AzureADTokenExchange"]
  issuer              = azurerm_kubernetes_cluster.this.oidc_issuer_url
  subject             = "system:serviceaccount:retail-${each.key}:spark-driver"
}

############################################
# Per-environment: Kubernetes Namespace
############################################
resource "kubernetes_namespace" "env" {
  for_each = var.environment_settings

  metadata {
    name = "retail-${each.key}"
    labels = {
      "environment"                  = each.key
      "app.kubernetes.io/managed-by" = "terraform"
    }
  }
}

############################################
# Per-environment: ResourceQuota
# THIS is the concrete, enforced difference between dev/test/prod namespaces:
# identical Kubernetes objects (SparkApplication, Pods, Services) behave
# identically, but the API server rejects anything that would push the
# namespace's aggregate requests/limits over these numbers.
############################################
resource "kubernetes_resource_quota" "env" {
  for_each = var.environment_settings

  metadata {
    name      = "retail-${each.key}-quota"
    namespace = kubernetes_namespace.env[each.key].metadata[0].name
  }

  spec {
    hard = {
      "requests.cpu"    = each.value.resource_quota_cpu
      "requests.memory" = each.value.resource_quota_memory
      "pods"            = each.value.resource_quota_pods
    }
  }
}

############################################
# Per-environment: NetworkPolicy
# Restricts ingress to pods in the SAME namespace only (plus kube-system for
# DNS/webhooks) - a dev pod cannot receive traffic from a test or prod pod
# even though all three share the one AKS cluster's network. Spark
# driver<->executor traffic is unaffected since they're always co-located in
# the same namespace.
############################################
resource "kubernetes_network_policy_v1" "isolate" {
  for_each = var.environment_settings

  metadata {
    name      = "retail-${each.key}-isolate"
    namespace = kubernetes_namespace.env[each.key].metadata[0].name
  }

  spec {
    pod_selector {}
    policy_types = ["Ingress"]

    ingress {
      from {
        namespace_selector {
          match_labels = {
            "kubernetes.io/metadata.name" = kubernetes_namespace.env[each.key].metadata[0].name
          }
        }
      }
      from {
        namespace_selector {
          match_labels = {
            "kubernetes.io/metadata.name" = "kube-system"
          }
        }
      }
    }
  }
}

############################################
# Per-environment: ServiceAccount for the Spark driver, federated to the
# environment's Managed Identity via Workload Identity.
############################################
resource "kubernetes_service_account" "spark_driver" {
  for_each = var.environment_settings

  metadata {
    name      = "spark-driver"
    namespace = kubernetes_namespace.env[each.key].metadata[0].name
    labels = {
      "azure.workload.identity/use" = "true"
    }
    annotations = {
      "azure.workload.identity/client-id" = azurerm_user_assigned_identity.env[each.key].client_id
    }
  }
}

############################################
# Optional per-environment: dedicated, tainted node pool
# Physical isolation layered on top of the namespace's logical isolation -
# only pods that explicitly tolerate `workload-env=<env>:NoSchedule` (see
# k8s/overlays/<env>/patch-sparkapplication.yaml) land here.
############################################
resource "azurerm_kubernetes_cluster_node_pool" "env" {
  for_each = { for k, v in var.environment_settings : k => v if v.enable_dedicated_node_pool }

  name                  = "np${each.key}"
  kubernetes_cluster_id = azurerm_kubernetes_cluster.this.id
  vm_size               = each.value.node_vm_size
  node_count            = each.value.node_count
  vnet_subnet_id        = azurerm_subnet.aks_nodes.id
  mode                  = "User"

  node_taints = ["workload-env=${each.key}:NoSchedule"]
  node_labels = {
    "workload-env" = each.key
  }

  tags = merge(var.tags, { environment = each.key })
}
