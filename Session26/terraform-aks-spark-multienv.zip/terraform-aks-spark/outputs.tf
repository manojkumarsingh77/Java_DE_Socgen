output "resource_group_name" {
  value = azurerm_resource_group.this.name
}

output "aks_cluster_name" {
  value = azurerm_kubernetes_cluster.this.name
}

output "aks_get_credentials_command" {
  description = "Run this locally to fetch kubeconfig for kubectl/spark-submit."
  value       = "az aks get-credentials --resource-group ${azurerm_resource_group.this.name} --name ${azurerm_kubernetes_cluster.this.name} --overwrite-existing"
}

output "acr_login_server" {
  value = azurerm_container_registry.this.login_server
}

output "acr_name" {
  value = azurerm_container_registry.this.name
}

output "log_analytics_workspace_id" {
  value = azurerm_log_analytics_workspace.this.workspace_id
}

output "vnet_id" {
  value = azurerm_virtual_network.this.id
}

output "aks_node_subnet_id" {
  value = azurerm_subnet.aks_nodes.id
}

output "aks_kube_config_host" {
  value     = azurerm_kubernetes_cluster.this.kube_config.0.host
  sensitive = true
}

############################################
# Multi-environment outputs
############################################

output "aks_oidc_issuer_url" {
  description = "Needed to verify the federated identity credential trust relationship."
  value       = azurerm_kubernetes_cluster.this.oidc_issuer_url
}

output "environment_namespaces" {
  description = "Kubernetes namespace name per environment."
  value       = { for k, v in kubernetes_namespace.env : k => v.metadata[0].name }
}

output "environment_managed_identity_client_ids" {
  description = <<-EOT
    Paste these into k8s/overlays/<env>/patch-serviceaccount.yaml in place of
    CHANGE_ME-<env>-entra-app-client-id - though if you deploy the
    ServiceAccount via this Terraform config (recommended - see
    kubernetes_service_account.spark_driver) the annotation is already wired
    automatically and you don't need to paste anything.
  EOT
  value = { for k, v in azurerm_user_assigned_identity.env : k => v.client_id }
}

output "environment_key_vault_uris" {
  description = "Set as secrets.key.vault.url in each application-<env>.conf."
  value       = { for k, v in azurerm_key_vault.env : k => v.vault_uri }
}

output "environment_storage_accounts" {
  description = "ADLS Gen2 storage account name per environment."
  value       = { for k, v in azurerm_storage_account.env : k => v.name }
}

output "environment_abfss_raw_paths" {
  description = "Set as storage.input.path in each application-<env>.conf."
  value = {
    for k, v in azurerm_storage_account.env :
    k => "abfss://raw@${v.name}.dfs.core.windows.net/pos-events/"
  }
}

output "environment_abfss_curated_paths" {
  description = "Set as storage.output.path in each application-<env>.conf."
  value = {
    for k, v in azurerm_storage_account.env :
    k => "abfss://curated@${v.name}.dfs.core.windows.net/promotion-scores/"
  }
}

output "spark_submit_commands" {
  description = "Ready-to-run spark-submit (cluster mode, plain CLI, no Spark Operator) per environment."
  value = {
    for env, ns in kubernetes_namespace.env :
    env => join(" ", [
      "spark-submit --master k8s://$(az aks show -g ${azurerm_resource_group.this.name} -n ${azurerm_kubernetes_cluster.this.name} --query fqdn -o tsv):443",
      "--deploy-mode cluster",
      "--name retail-promotion-${env}",
      "--class com.retailbank.pipeline.PromotionPipeline",
      "--conf spark.kubernetes.namespace=${ns.metadata[0].name}",
      "--conf spark.kubernetes.authenticate.driver.serviceAccountName=spark-driver",
      "--conf spark.kubernetes.container.image=${azurerm_container_registry.this.login_server}/retail-platform-promotion-model:demo-v1",
      "--conf spark.driver.extraJavaOptions=-Denv=${env}",
      "--conf spark.executor.extraJavaOptions=-Denv=${env}",
      "local:///opt/spark/jars/retail-platform-promotion-model-1.0.0.jar"
    ])
  }
}
