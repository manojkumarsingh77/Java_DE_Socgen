terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.107"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.31"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # Local state by default. If you want remote state (recommended for teams),
  # uncomment and configure an azurerm backend pointing to a storage account
  # you provision separately (chicken-and-egg problem, so keep it manual/local
  # for a fundamentals cluster like this one).
  #
  # backend "azurerm" {
  #   resource_group_name  = "rg-tfstate"
  #   storage_account_name = "sttfstateuniquename"
  #   container_name       = "tfstate"
  #   key                  = "aks-spark-fundamentals.tfstate"
  # }
}

provider "azurerm" {
  features {
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
    key_vault {
      # Lets `terraform destroy` actually remove Key Vaults instead of just
      # soft-deleting them and leaving name collisions behind on the next apply.
      purge_soft_delete_on_destroy    = true
      recover_soft_deleted_key_vaults = true
    }
  }

  subscription_id = var.subscription_id
}

# Wired to the AKS cluster's LOCAL ADMIN kube_config (client-certificate
# auth), not your `az aks get-credentials` context. This is what lets
# Terraform create Kubernetes objects (namespaces, service accounts,
# resource quotas, network policies) in the same `apply` that creates the
# cluster, without you needing to run `az aks get-credentials` first.
#
# Lab simplification: this requires the cluster's local accounts to be
# enabled (`local_account_disabled = false`, the AKS default, and what this
# config uses). A cluster with Azure AD-only auth enforced would need the
# `exec` block below instead, using `kubelogin`:
#
# provider "kubernetes" {
#   host                   = azurerm_kubernetes_cluster.this.kube_config[0].host
#   cluster_ca_certificate = base64decode(azurerm_kubernetes_cluster.this.kube_config[0].cluster_ca_certificate)
#   exec {
#     api_version = "client.authentication.k8s.io/v1beta1"
#     command     = "kubelogin"
#     args        = ["get-token", "--login", "azurecli", "--server-id", "6dae42f8-4368-4678-94ff-3960e28e3630"]
#   }
# }
provider "kubernetes" {
  host                   = azurerm_kubernetes_cluster.this.kube_config[0].host
  client_certificate     = base64decode(azurerm_kubernetes_cluster.this.kube_config[0].client_certificate)
  client_key             = base64decode(azurerm_kubernetes_cluster.this.kube_config[0].client_key)
  cluster_ca_certificate = base64decode(azurerm_kubernetes_cluster.this.kube_config[0].cluster_ca_certificate)
}

