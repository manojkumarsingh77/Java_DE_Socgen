# DR Demonstration Runbook — Cross-Region Failover (Real Infrastructure)
### Layer 1 (Terraform/Azure) builds it. Layer 2 (this app) just reads config. Azure/kubectl operate the failover.

This runbook demonstrates disaster recovery the way an enterprise actually
experiences it: **the same Docker image, the same JAR, redeployed to a
different cluster with different configuration** — no rebuild, no redeploy
of code, no `if (region == primary)` anywhere.

It assumes `terraform-dr-ha-lab` has already been applied (both AKS
clusters, both Event Hubs namespaces, both storage accounts, the shared Key
Vault, and RBAC all exist) and this app's image has been built and pushed to
ACR **once**.

---

## The two-layer boundary, stated explicitly

```
┌─────────────────────────────────────────────────────────────┐
│ LAYER 1 — Infrastructure (Terraform + Azure)                 │
│   terraform apply   →  builds AKS×2, Event Hub×2, Storage×2, │
│                        ACR, Key Vault, VNets, RBAC            │
│   Then STOPS. Terraform is never invoked again during the    │
│   demo. It built the stage; it does not perform on it.        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 2 — Application (this repo)                             │
│   Same image. Same JAR. Deployed to whichever cluster is      │
│   currently active, reading whichever ConfigMap that cluster  │
│   was given. The failover ITSELF happens via kubectl/az       │
│   commands below — never via Terraform, never via a code      │
│   change in this repo.                                        │
└─────────────────────────────────────────────────────────────┘
```

If at any point during the demo you find yourself reaching for
`terraform apply` to "make the failover happen" — stop. That's the
anti-pattern this runbook exists to avoid. Terraform's job ended when the
infrastructure existed.

---

## Pre-demo setup (once, before the audience arrives)

```bash
# 1. Pull everything you need from the infra layer
cd terraform-dr-ha-lab
terraform output -json > /tmp/tf-outputs.json
PRIMARY_EHNS=$(jq -r '.eventhub_namespace_fqdns.value.primary' /tmp/tf-outputs.json)
SECONDARY_EHNS=$(jq -r '.eventhub_namespace_fqdns.value.secondary' /tmp/tf-outputs.json)
PRIMARY_STORAGE=$(jq -r '.storage_account_names.value.primary' /tmp/tf-outputs.json)
SECONDARY_STORAGE=$(jq -r '.storage_account_names.value.secondary' /tmp/tf-outputs.json)
ACR_SERVER=$(jq -r '.acr_login_server.value' /tmp/tf-outputs.json)
KV_NAME=$(jq -r '.key_vault_name.value' /tmp/tf-outputs.json)

# 2. Fill in the k8s/*.yaml placeholders with the values above
cd ../dr-aware-spark-app
sed -i '' "s/<PRIMARY_EVENTHUB_NAMESPACE>/${PRIMARY_EHNS}/"   k8s/configmap-primary.yaml
sed -i '' "s/<SECONDARY_EVENTHUB_NAMESPACE>/${SECONDARY_EHNS}/" k8s/configmap-secondary.yaml
sed -i '' "s/<PRIMARY_STORAGE_ACCOUNT_NAME>/${PRIMARY_STORAGE}/"   k8s/configmap-primary.yaml
sed -i '' "s/<SECONDARY_STORAGE_ACCOUNT_NAME>/${SECONDARY_STORAGE}/" k8s/configmap-secondary.yaml
sed -i '' "s|<KEY_VAULT_NAME>|${KV_NAME}|" k8s/configmap-primary.yaml k8s/configmap-secondary.yaml \
                                            k8s/secretproviderclass-primary.yaml k8s/secretproviderclass-secondary.yaml
sed -i '' "s|<ACR_LOGIN_SERVER>|${ACR_SERVER}|" k8s/sparkapplication-primary.yaml k8s/sparkapplication-secondary.yaml

# 3. Build and push the image ONCE
docker build -f docker/Dockerfile -t ${ACR_SERVER}/dr-aware-spark-app:1.0.0 .
az acr login --name $(echo ${ACR_SERVER} | cut -d. -f1)
docker push ${ACR_SERVER}/dr-aware-spark-app:1.0.0

# 4. kubeconfig for both clusters
az aks get-credentials -g rg-datahulk-primary-*   -n aks-datahulk-primary-*   --context primary
az aks get-credentials -g rg-datahulk-secondary-* -n aks-datahulk-secondary-* --context secondary
```

**THE POINT TO MAKE OUT LOUD HERE:** step 3 (`docker push`) happens exactly
once, before the demo starts, and never again — not even during "failover."
Write the image digest on the whiteboard now; you'll show it's unchanged at
the end.

```bash
docker inspect ${ACR_SERVER}/dr-aware-spark-app:1.0.0 --format='{{.Id}}' | tee /tmp/image-digest-before.txt
```

---

## Step 1 — Normal Operation (Primary)

```bash
kubectl --context primary create namespace data-platform-dr --dry-run=client -o yaml | kubectl --context primary apply -f -
kubectl --context primary apply -f k8s/configmap-primary.yaml
kubectl --context primary apply -f k8s/secretproviderclass-primary.yaml
kubectl --context primary apply -f k8s/sparkapplication-primary.yaml
```

Send test traffic:
```bash
PRIMARY_CONN=$(az keyvault secret show --vault-name ${KV_NAME} --name eventhub-conn-primary --query value -o tsv)
./scripts/produce-test-events.sh "${PRIMARY_EHNS}" "${PRIMARY_CONN}" 100
```

**Show the audience, live:**
```bash
kubectl --context primary logs -n data-platform-dr -l region=primary -f --tail=30
# expect: "Streaming query started ..." then micro-batch progress logs every 10s

./scripts/verify-output.sh ${PRIMARY_STORAGE} ledger
# expect: growing list of .parquet files under txn_ledger/, fresh _delta_log commit
```

Checklist:
- [ ] Spark consuming from `banking-transactions` on the primary Event Hub
- [ ] Micro-batches processing every 10s (see `Trigger.ProcessingTime`)
- [ ] Delta files landing in `${PRIMARY_STORAGE}`
- [ ] Logs show `processedAtRegion = us-east-primary` (query the Delta table, or `kubectl logs`)

---

## Step 2 — Simulate Region Failure

Pick the failure mode that matches what you want to teach; each is a real,
distinct operational technique:

**Option A — Hard stop (simulates full outage):**
```bash
kubectl --context primary delete -f k8s/sparkapplication-primary.yaml
kubectl --context primary scale --replicas=0 deployment -n data-platform-dr -l region=primary --all 2>/dev/null || true
az aks nodepool scale --resource-group rg-datahulk-primary-* --cluster-name aks-datahulk-primary-* \
   --name system --node-count 0
```

**Option B — Event Hubs Geo-DR alias failover (simulates a coordinated, graceful failover):**
```bash
az eventhubs georecovery-alias fail-over \
  --resource-group rg-datahulk-primary-* \
  --namespace-name ${PRIMARY_EHNS} \
  --alias ehdr-datahulk-*
```
Narrate: this flips the alias FQDN to point at the (former) secondary
namespace — clients using the *alias* rather than a hardcoded namespace
would not need reconfiguration at all. Our `RegionConfig` currently points
directly at each namespace (simpler for this demo), so we still redeploy
with a new ConfigMap in Step 3 — call this out as the production refinement
(point `KAFKA_BOOTSTRAP_SERVERS` at the alias FQDN instead of a specific
namespace, and Step 3 becomes a no-op for this setting).

**Option C — No traffic manager needed for this demo** (Front Door/Traffic
Manager route *end users* to whichever region is serving; they don't route
Spark's Kafka consumer connection, so are out of scope for this specific
data-pipeline failover — mention this distinction if asked).

---

## Step 3 — Start Secondary (Same Image)

```bash
kubectl --context secondary create namespace data-platform-dr --dry-run=client -o yaml | kubectl --context secondary apply -f -
kubectl --context secondary apply -f k8s/configmap-secondary.yaml
kubectl --context secondary apply -f k8s/secretproviderclass-secondary.yaml
kubectl --context secondary apply -f k8s/sparkapplication-secondary.yaml
```

**Show the audience, live — this is the actual proof:**
```bash
diff k8s/sparkapplication-primary.yaml k8s/sparkapplication-secondary.yaml
# only the `region:` label differs — image, mainClass, mainApplicationFile,
# sparkConf, resources: byte-for-byte identical

docker inspect ${ACR_SERVER}/dr-aware-spark-app:1.0.0 --format='{{.Id}}' | diff - /tmp/image-digest-before.txt && echo "IMAGE UNCHANGED"
```

---

## Step 4 — Resume Processing (Secondary)

```bash
SECONDARY_CONN=$(az keyvault secret show --vault-name ${KV_NAME} --name eventhub-conn-secondary --query value -o tsv)
./scripts/produce-test-events.sh "${SECONDARY_EHNS}" "${SECONDARY_CONN}" 100

kubectl --context secondary logs -n data-platform-dr -l region=secondary -f --tail=30
```

---

## Step 5 — Validate

```bash
./scripts/verify-output.sh ${SECONDARY_STORAGE} ledger
```

Read out the checklist to the room:

- [ ] Messages are being processed again — **on the secondary Event Hub**
- [ ] **No code changes** — `git diff` on this repo since Step 1 shows nothing
- [ ] **Same Docker image** — digest comparison above matches
- [ ] **Same JAR** — `jar tf` the artifact from both clusters' pod filesystems and `diff` the listings/checksums if you want to be thorough:
  ```bash
  kubectl --context primary   exec -n data-platform-dr <old-driver-pod-if-still-around> -- sha256sum /opt/dr-aware-app/jars/app.jar
  kubectl --context secondary exec -n data-platform-dr <driver-pod> -- sha256sum /opt/dr-aware-app/jars/app.jar
  ```
- [ ] **Different region** — `processedAtRegion` column in the new Delta files reads `us-west-secondary`

That combination — identical binary, identical behavior, different
region, achieved through configuration alone — is the actual deliverable
of a DR program. Everything upstream of it (RPO/RTO targets, replication
lag, backup cadence) determines *how much it costs* to get here; this
final step is what "recovered" concretely looks like.

---

## Why there's no `if (region.equals("primary"))` anywhere

If you're asked "but what decides which Event Hub to read from?" — the
honest answer is: **a human (or a deployment pipeline) decided, once, at
`kubectl apply` time, by choosing which ConfigMap to apply.** The
application never makes that decision itself, for the same reason a stateless
web server doesn't decide which database shard it's talking to — that's a
deployment-time concern, not a runtime concern. Baking `if (region ==
"primary")` into the JAR would mean:

- A code change (and redeploy, and re-test, and re-approve) is required to
  fail over — turning a config change into a release event.
- The "primary" and "secondary" code paths inevitably drift from each other
  over time (different bug fixes land in one branch of the `if` and not the
  other) — exactly the kind of asymmetry that causes a failover to behave
  unexpectedly during the one moment you can least afford surprises.
- You can no longer answer "did the outage change what code ran?" with a
  simple "no."

---

## Cleanup

```bash
kubectl --context primary   delete -f k8s/sparkapplication-primary.yaml   --ignore-not-found
kubectl --context secondary delete -f k8s/sparkapplication-secondary.yaml --ignore-not-found
az aks nodepool scale --resource-group rg-datahulk-primary-* --cluster-name aks-datahulk-primary-* --name system --node-count 2
```
(Full infrastructure teardown is `terraform destroy` in `terraform-dr-ha-lab`
— per the boundary above, that's the only Terraform command you should run
in connection with this demo, and only after it's fully over.)
