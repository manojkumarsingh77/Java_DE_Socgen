# dr-aware-spark-app

Layer 2 of the DR demonstration: a Spark Structured Streaming app that is
**DR-aware, not DR-responsible**. It reads its Event Hub / Storage / Key
Vault coordinates from environment variables injected by Kubernetes
(`RegionConfig.fromEnvironment()`), contains zero region-conditional logic,
and is built into exactly one Docker image that gets deployed, unmodified,
to both the primary and secondary AKS clusters provisioned by
`terraform-dr-ha-lab`.

**Start here:** [`DR_DEMO_RUNBOOK.md`](./DR_DEMO_RUNBOOK.md) — the full
5-step live demonstration (normal operation → simulate failure → deploy
secondary → resume → validate), with exact commands.

## Relationship to the other two projects in this series

| Project | Purpose |
|---|---|
| `dr-ha-spark-demo` | Teaches RPO/RTO **measurement** — one process plays both regions in-memory so the math (achieved RPO, achieved RTO, data-loss enumeration) is directly observable. Local-only, no cloud dependency. |
| `terraform-dr-ha-lab` | Layer 1 — builds the real dual-region Azure infrastructure this app runs on, then stops. Never re-run during a failover. |
| `dr-aware-spark-app` (this project) | Layer 2 — proves the **operational** failover pattern enterprises actually use: same image, same JAR, config-only redeploy. Runs against the real infrastructure from `terraform-dr-ha-lab`. |

## File map

```
pom.xml                              Java 17 / Spark 3.5.1 / Delta / Kafka connector
src/.../config/RegionConfig.java     ALL "DR-awareness" lives here — read-only config, no branching
src/.../model/BankingEvent.java      Event schema (matches the earlier synthetic generator)
src/.../DrAwareStreamingApp.java     The entire app: read config, consume, transform, write Delta
docker/Dockerfile                    Built once, pushed once, deployed to both regions unmodified
k8s/configmap-{primary,secondary}.yaml            Diff these two — that diff IS the failover
k8s/secretproviderclass-{primary,secondary}.yaml  Key Vault CSI mounts, per-region managed identity
k8s/sparkapplication-{primary,secondary}.yaml     Diff these two — only region label differs
scripts/produce-test-events.sh       Synthetic transaction producer (kcat against Event Hub Kafka endpoint)
scripts/verify-output.sh             Confirms Delta files landed in the target region's storage
DR_DEMO_RUNBOOK.md                   The full live-demo script
```
