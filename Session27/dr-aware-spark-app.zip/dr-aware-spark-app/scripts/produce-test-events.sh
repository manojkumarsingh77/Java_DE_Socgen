#!/usr/bin/env bash
# ============================================================================
# produce-test-events.sh — sends synthetic banking transactions to whichever
# Event Hub you point it at (primary or secondary), using kcat (kafkacat)
# against the Event Hubs "for Kafka" endpoint. This script has the SAME
# "no region logic" property as the app itself: it just takes a namespace +
# connection string as arguments.
#
# Install kcat:  brew install kcat  (macOS)  |  apt install kafkacat (Linux)
# ============================================================================
set -euo pipefail

NAMESPACE="${1:?Usage: produce-test-events.sh <namespace>.servicebus.windows.net <connection-string> <count>}"
CONN_STRING="${2:?Usage: produce-test-events.sh <namespace>.servicebus.windows.net <connection-string> <count>}"
COUNT="${3:-50}"
TOPIC="banking-transactions"

TYPES=(DEBIT CREDIT TRANSFER ATM_WITHDRAWAL POS_PAYMENT)
CURR=(USD USD USD EUR GBP)

echo "Sending ${COUNT} synthetic transactions to ${NAMESPACE}:9093 / topic ${TOPIC}"

for i in $(seq 1 "${COUNT}"); do
  TXN_ID="TXN-DEMO-$(date +%s)-${i}"
  TYPE=${TYPES[$((RANDOM % 5))]}
  CUR=${CURR[$((RANDOM % 5))]}
  AMOUNT=$(awk -v seed="$RANDOM" 'BEGIN{srand(seed); printf "%.2f", 5 + rand()*9995}')
  TS=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")

  cat <<EOF | kcat -P -b "${NAMESPACE}:9093" \
      -X security.protocol=SASL_SSL -X sasl.mechanism=PLAIN \
      -X sasl.username='$ConnectionString' -X sasl.password="${CONN_STRING}" \
      -t "${TOPIC}"
{"transactionId":"${TXN_ID}","accountId":"ACC-$((RANDOM % 2000000))","customerId":"CUST-$((RANDOM % 500000))","branchId":"BR-NYC-001","transactionType":"${TYPE}","amount":${AMOUNT},"currency":"${CUR}","status":"POSTED","eventTimestamp":"${TS}"}
EOF
done

echo "Done. Verify consumption with scripts/verify-output.sh"
