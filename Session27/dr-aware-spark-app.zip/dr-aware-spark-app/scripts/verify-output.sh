#!/usr/bin/env bash
# verify-output.sh <storage-account-name> <container> — lists recent Delta
# files and prints the latest processedAtRegion tag values, so you can show
# the class "this batch was processed in us-west-secondary" without touching
# any application code or config beyond what's already deployed.
set -euo pipefail

STORAGE_ACCOUNT="${1:?Usage: verify-output.sh <storage-account-name> <container>}"
CONTAINER="${2:-ledger}"

echo "== Delta table files under abfss://${CONTAINER}@${STORAGE_ACCOUNT}.dfs.core.windows.net/txn_ledger =="
az storage fs file list \
  --account-name "${STORAGE_ACCOUNT}" \
  --file-system "${CONTAINER}" \
  --path "txn_ledger" \
  --auth-mode login \
  --query "[?ends_with(name, '.parquet')].{name:name, lastModified:properties.lastModified}" \
  -o table | tail -20

echo
echo "== Latest _delta_log commit (shows the write actually happened) =="
az storage fs file list \
  --account-name "${STORAGE_ACCOUNT}" \
  --file-system "${CONTAINER}" \
  --path "txn_ledger/_delta_log" \
  --auth-mode login \
  --query "sort_by([?ends_with(name, '.json')], &properties.lastModified)[-1]" \
  -o table
