package com.retailbank.draware;

import com.retailbank.draware.config.RegionConfig;
import com.retailbank.draware.model.BankingEvent;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.Trigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeoutException;

import static org.apache.spark.sql.functions.*;

/**
 * Layer 2 of the DR demo: "DR-aware, not DR-responsible."
 *
 * This class consumes retail-banking transaction events from an Event Hub
 * (via the Kafka-compatible endpoint), does a minimal transform, and writes
 * to a Delta table on ADLS Gen2 — using ONLY values from RegionConfig.
 *
 * Read this file end to end: there is no branch, no field, no method here
 * that asks "am I in the primary or secondary region?" The exact same
 * compiled class runs identically in both regions. The only thing that
 * changes between a primary deployment and a secondary deployment is the
 * Kubernetes ConfigMap/SecretProviderClass supplied at deploy time (see
 * k8s/configmap-primary.yaml vs k8s/configmap-secondary.yaml — diff them,
 * they differ only in values, never in structure).
 *
 * "Failover," from this application's point of view, is indistinguishable
 * from "first deployment to a new cluster." That is the whole point.
 */
public final class DrAwareStreamingApp {

    private static final Logger log = LoggerFactory.getLogger(DrAwareStreamingApp.class);

    public static void main(String[] args) throws TimeoutException, InterruptedException {
        RegionConfig config = RegionConfig.fromEnvironment();

        log.info("Starting DR-aware streaming app. regionLabel='{}' (informational tag only — " +
                "no behavior in this application depends on this value)", config.regionLabel());
        log.info("kafkaBootstrapServers={} eventHub={} deltaTablePath={}",
                config.kafkaBootstrapServers(), config.eventHubName(), config.deltaTablePath());

        SparkSession spark = SparkSession.builder()
                .appName("dr-aware-spark-app")
                .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
                .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
                .getOrCreate();

        spark.sparkContext().setLogLevel("WARN");

        Dataset<Row> kafkaStream = spark.readStream()
                .format("kafka")
                .option("kafka.bootstrap.servers", config.kafkaBootstrapServers())
                .option("subscribe", config.eventHubName())
                .option("kafka.sasl.mechanism", "PLAIN")
                .option("kafka.security.protocol", "SASL_SSL")
                .option("kafka.sasl.jaas.config", config.kafkaSaslJaasConfig())
                .option("startingOffsets", "earliest")
                .option("failOnDataLoss", "false")
                .load();

        Dataset<Row> parsed = kafkaStream
                .selectExpr("CAST(value AS STRING) AS json", "timestamp AS kafkaTimestamp")
                .select(from_json(col("json"), BankingEvent.SCHEMA).as("event"), col("kafkaTimestamp"))
                .select("event.*", "kafkaTimestamp")
                .withColumn("processedAtRegion", lit(config.regionLabel())) // observability tag ONLY — never read back by this app
                .withColumn("processingTimestamp", current_timestamp());

        StreamingQuery query = parsed.writeStream()
                .format("delta")
                .outputMode("append")
                .option("checkpointLocation", config.checkpointPath())
                .trigger(Trigger.ProcessingTime("10 seconds"))
                .start(config.deltaTablePath());

        log.info("Streaming query started: {}. Writing to {}", query.id(), config.deltaTablePath());

        query.awaitTermination();
    }
}
