package com.retailbank.draware.config;

/**
 * Everything this application knows about "which region it's in" is confined
 * to this one class, and even here it's read-only, passive information used
 * for LOGGING/TAGGING ONLY — never for branching control flow.
 *
 * There is deliberately no `if (regionLabel.equals("primary")) { ... }`
 * anywhere in this codebase, including here. The Kafka bootstrap servers,
 * storage account, and Key Vault URI are just... values. The application
 * doesn't know or care whether they point at the "primary" or "secondary"
 * Azure region — that distinction exists only in the mind of the operator
 * deploying this same, unmodified JAR with a different ConfigMap.
 *
 * Resolution order per setting: environment variable (set by the K8s
 * ConfigMap/Secret in k8s/*.yaml) > Java system property > hard failure.
 * No hardcoded fallback values are used for the DR-relevant settings —
 * a missing value should fail fast at startup, not silently default to
 * something that might be the WRONG region's endpoint.
 */
public record RegionConfig(
        String regionLabel,             // free-text tag for logs/metrics only, e.g. "us-east" or "us-west" — never branched on
        String kafkaBootstrapServers,    // Event Hubs "for Kafka" endpoint, e.g. ehns-...servicebus.windows.net:9093
        String eventHubName,             // the Kafka "topic" name = the Event Hub name
        String eventHubConnectionString, // used to build the SASL_SSL jaas config; sourced via Key Vault CSI mount, see k8s/secretproviderclass-*.yaml
        String storageAccountName,
        String storageContainer,
        String deltaTablePath,           // full abfss:// path, derived from storageAccountName + storageContainer + a fixed table name
        String checkpointPath,
        String keyVaultUri
) {

    public static RegionConfig fromEnvironment() {
        return new RegionConfig(
                required("REGION_LABEL"),
                required("KAFKA_BOOTSTRAP_SERVERS"),
                required("EVENTHUB_NAME"),
                required("EVENTHUB_CONNECTION_STRING"),
                required("STORAGE_ACCOUNT_NAME"),
                required("STORAGE_CONTAINER"),
                buildAbfssPath(required("STORAGE_ACCOUNT_NAME"), required("STORAGE_CONTAINER"), "txn_ledger"),
                buildAbfssPath(required("STORAGE_ACCOUNT_NAME"), required("STORAGE_CONTAINER"), "_checkpoints/txn_ledger"),
                required("KEYVAULT_URI")
        );
    }

    private static String buildAbfssPath(String account, String container, String path) {
        return "abfss://" + container + "@" + account + ".dfs.core.windows.net/" + path;
    }

    private static String required(String envVar) {
        String value = System.getenv(envVar);
        if (value == null || value.isBlank()) {
            value = System.getProperty(envVar);
        }
        if (value == null || value.isBlank()) {
            throw new IllegalStateException(
                    "Missing required configuration: " + envVar + ". This application performs no " +
                    "region-specific fallback — every DR-relevant setting must be supplied explicitly " +
                    "by the deployment's ConfigMap/SecretProviderClient (see k8s/configmap-*.yaml). " +
                    "Failing fast here is intentional: a silently-defaulted Event Hub or Storage endpoint " +
                    "during a failover drill is exactly the kind of bug this design is meant to prevent.");
        }
        return value;
    }

    /** Kafka client config for the Event Hubs "for Kafka" SASL_SSL endpoint. No region-specific logic. */
    public String kafkaSaslJaasConfig() {
        return "org.apache.kafka.common.security.plain.PlainLoginModule required " +
                "username=\"$ConnectionString\" " +
                "password=\"" + eventHubConnectionString + "\";";
    }
}
