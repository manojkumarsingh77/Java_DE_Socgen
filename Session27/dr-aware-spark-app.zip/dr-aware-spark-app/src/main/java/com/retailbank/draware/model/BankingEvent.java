package com.retailbank.draware.model;

import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

/** JSON schema of the events flowing through Event Hub. Kept intentionally identical
 *  to the earlier SyntheticBankingDataGenerator schema so the same producer tooling
 *  can feed both the local demo and this real-infrastructure app. */
public final class BankingEvent {

    public static final StructType SCHEMA = new StructType(new StructField[]{
            field("transactionId", DataTypes.StringType),
            field("accountId", DataTypes.StringType),
            field("customerId", DataTypes.StringType),
            field("branchId", DataTypes.StringType),
            field("transactionType", DataTypes.StringType),
            field("amount", DataTypes.DoubleType),
            field("currency", DataTypes.StringType),
            field("status", DataTypes.StringType),
            field("eventTimestamp", DataTypes.TimestampType)
    });

    private BankingEvent() {}

    private static StructField field(String name, org.apache.spark.sql.types.DataType type) {
        return new StructField(name, type, false, Metadata.empty());
    }
}
