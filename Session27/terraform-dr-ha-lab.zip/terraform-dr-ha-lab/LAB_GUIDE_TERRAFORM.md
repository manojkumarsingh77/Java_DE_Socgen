# Lab Guide — Provisioning Cross-Region DR/HA Infrastructure with Terraform
### Session 22 · Disaster Recovery & High Availability · Cross-Region Failover Simulation (Infrastructure Layer)

This guide provisions the **real Azure infrastructure** that the
`dr-ha-spark-demo` Java/Spark application (from the earlier lab) can run
against, entirely within your lab control panel's allow-list. It also
contains a **deliberate bug-lab exercise** — a common, realistic Terraform
mistake, the exact error it produces, and the correct architectural fix —
so the debugging skill from the application lab carries over to the
infrastructure layer.

---

## 1. What Gets Built

| Layer | Primary region (default: East US) | Secondary region (default: East US2) |
|---|---|---|
| Resource Group | ✅ | ✅ |
| VNet + Subnet + NSG | 10.10.0.0/16 | 10.20.0.0/16 |
| AKS (Standard tier, D2_v3 nodes) | ✅ | ✅ |
| ADLS Gen2 Storage (Standard_LRS) | `primary_txn_ledger` | `secondary_txn_ledger` |
| Event Hubs namespace (Standard) | ✅ | ✅ (+ Geo-DR alias pairing) |
| Log Analytics + App Insights | ✅ | ✅ |
| Recovery Services Vault + Files backup | ✅ | ✅ |
| User-Assigned Managed Identity | ✅ | ✅ |
| ACR (Basic) | ✅ single instance | *(bug-lab adds a second)* |
| Key Vault (Standard) | ✅ single, shared | — |
| Azure Policy guardrails | subscription-scoped, covers both regions | |

**Read this before you build a DR narrative on top of it:** East US and
East US2 are **not** an official Azure paired region (nor are any two of
the four sandbox-allowed regions). This lab deliberately does *not* lean on
paired-region platform features (e.g. GRS storage — also not permitted by
the sandbox anyway) — replication is implemented explicitly at the
application/Terraform layer instead, which is actually the more instructive
version of this lesson.

---

## 2. Prerequisites

```bash
az --version            # Azure CLI 2.60+
terraform -version      # Terraform 1.7+
az login
az account set --subscription "<your-lab-subscription-id>"
az account show --query id -o tsv   # copy this into terraform.tfvars
```

Confirm your lab identity has at minimum **Contributor** + **User Access
Administrator** (or **Owner**) on the subscription — the RBAC role
assignments in `rbac.tf` and policy assignments in `policy.tf` need the
latter.

```bash
az role assignment list --assignee $(az ad signed-in-user show --query id -o tsv) \
  --query "[].roleDefinitionName" -o tsv
```

---

## 3. Lab Steps — Phase 1: Bootstrap

### Step 3.1 — Configure variables
```bash
cd terraform-dr-ha-lab
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars: set subscription_id, review region/SKU defaults
```

### Step 3.2 — Init
```bash
terraform init
```
**Checkpoint:** should report `Terraform has been successfully initialized!`
with `hashicorp/azurerm ~> 3.100` and `hashicorp/random ~> 3.6` resolved.

### Step 3.3 — Validate the guardrail variables *before* touching Azure
```bash
terraform console
> var.primary_region
> var.aks_node_vm_size
```
Then deliberately break a validation rule to see the guardrail work:
```bash
terraform plan -var="aks_node_vm_size=Standard_E4s_v3"
```
**Expected:** Terraform refuses at plan time with the custom `validation`
error message from `variables.tf`, *before* any API call to Azure — this is
strictly faster feedback than waiting for an Azure Policy denial.

---

## 4. Lab Steps — Phase 2: Governance-First Apply (Azure Policy)

Because the policy assignments in `policy.tf` are subscription-scoped and
the resources they govern are created in the same configuration, apply the
policy layer first so it's actually enforcing by the time the rest of the
plan runs:

```bash
terraform apply \
  -target=azurerm_subscription_policy_assignment.allowed_locations \
  -target=azurerm_subscription_policy_assignment.allowed_vm_skus \
  -target=azurerm_subscription_policy_assignment.storage_sku_allowlist \
  -target=azurerm_subscription_policy_assignment.acr_sku_allowlist \
  -target=azurerm_subscription_policy_assignment.require_module_tag
```
Type `yes` to confirm. **Checkpoint:**
```bash
az policy assignment list --query "[?starts_with(name,'lab-')].name" -o tsv
```
should list all five.

*(Using `-target` outside a one-off situation like this is normally
discouraged — Terraform's docs warn it can produce a plan inconsistent with
a full run. Here it's the correct, intentional pattern: a genuine two-phase
rollout, not a workaround for a stuck state. Follow it with a full `apply`
next so Terraform reconciles everything against one consistent plan.)*

---

## 5. Lab Steps — Phase 3: Full Infrastructure Apply

```bash
terraform plan -out=tfplan
```
Review the plan — expect roughly 45-55 resources to add (2× everything in
the per-region tables above, plus the shared ACR/Key Vault/policy set).

```bash
terraform apply tfplan
```
This takes **12–20 minutes**, dominated by the two AKS cluster creations
(they provision in parallel since they're `for_each`, not sequential).

**Checkpoint:**
```bash
terraform output aks_cluster_names
terraform output aks_get_credentials_commands
```
Run both printed `az aks get-credentials` commands, then:
```bash
kubectl --context primary get nodes
kubectl --context secondary get nodes
```
Both should show `Ready` nodes matching `aks_node_count` (default 2).

---

## 6. Lab Steps — Phase 4: Verify Every Allow-Listed Service Landed Correctly

Work through this checklist — it doubles as a guided tour of what Terraform
just built and *why* each piece maps to a DR/HA topic:

```bash
# AKS — confirm both clusters, correct tier and node VM size
az aks list -o table

# ACR — confirm Basic SKU (and that it's the single, primary-region instance)
az acr show --name $(terraform output -raw acr_login_server | cut -d. -f1) --query "{sku:sku.name, location:location}"

# ADLS Gen2 — confirm HNS enabled + LRS on both storage accounts
terraform output storage_account_names
az storage account list --query "[?contains(name,'st${var.name_prefix}')].{name:name, sku:sku.name, hns:isHnsEnabled}" -o table

# Event Hubs — confirm Standard SKU + Geo-DR alias
az eventhubs namespace list -o table
az eventhubs georecovery-alias list --resource-group $(terraform output -json resource_groups | jq -r .primary) \
  --namespace-name <primary-ehns-name>

# Key Vault — confirm RBAC-mode, Standard SKU, secrets present
az keyvault secret list --vault-name $(terraform output -raw key_vault_name) -o table

# Recovery Services Vault — confirm Files share is protected
az backup item list --resource-group $(terraform output -json resource_groups | jq -r .primary) \
  --vault-name $(terraform output -json recovery_services_vault_names | jq -r .primary) -o table

# Azure Policy — confirm all five assignments are Enforcement Mode = Default (enforced)
az policy assignment list --query "[?starts_with(name,'lab-')].{name:name, enforcementMode:enforcementMode}" -o table
```

---

## 7. Lab Steps — Phase 5: Run the Spark DR App Against Real Infra

1. Update the Spark app's `AppConfig` (from the earlier lab) using the
   Terraform outputs:
   ```bash
   terraform output storage_abfss_paths
   ```
   Replace `primaryTablePath` / `secondaryTablePath` with these `abfss://` URIs.
2. Add the Hadoop-Azure auth config so Spark can authenticate to ADLS Gen2
   using the region's managed identity (workload identity federation) instead
   of a storage key:
   ```java
   .config("spark.hadoop.fs.azure.account.auth.type", "OAuth")
   .config("spark.hadoop.fs.azure.account.oauth.provider.type",
           "org.apache.hadoop.fs.azurebfs.oauth2.MsiTokenProvider")
   ```
3. Push the image, deploy via `k8s/spark-application.yaml` from the earlier
   lab, but update `spec.image` to `terraform output acr_login_server` and
   apply against **both** kube contexts:
   ```bash
   kubectl --context primary apply -f k8s/spark-application.yaml
   ```
4. Confirm in Log Analytics (using the saved search from `monitoring.tf`):
   ```bash
   az monitor log-analytics query \
     --workspace $(terraform output -json log_analytics_workspace_ids | jq -r .primary) \
     --analytics-query "ContainerLogV2 | where LogMessage has 'SECONDARY apply' | take 20"
   ```
5. Run the full failure drill exactly as in the application lab — now with
   real cross-region network latency between the two ADLS Gen2 accounts
   contributing to the *actual* replication lag, instead of a simulated
   `Thread.sleep`. Compare the achieved RPO to the local-demo numbers and
   discuss the delta with the class.

---

## 8. Bug-Lab: Find and Fix a Real Terraform DR Mistake

### Step 8.1 — Reproduce the bug
```bash
cp bug-lab/01-broken-acr-georeplication.tf.txt acr-georeplication.tf
terraform plan
```
**Expected output (paraphrased):**
```
Error: geo-replication can only be configured for a Premium Sku Container Registry, got "Basic"
```
or, on some provider versions, a schema-level conflict error on the
`georeplications` block itself. Either way — **it fails**, and it fails for
an architectural reason (SKU capability), not a typo.

### Step 8.2 — Diagnose using the structured method from the application lab
1. **Read the error, not just the resource name.** It names the SKU
   constraint explicitly — this is not a permissions or quota error.
2. **Check the constraint against the allow-list.** `acr_sku` is
   hard-validated to `"Basic"` in `variables.tf` — Premium was never an
   option, so "just switch to Premium" is not an available fix here.
3. **Ask what the feature actually buys you**, independent of SKU: automatic,
   transparent multi-region image availability with a single registry FQDN.
   Given Basic-only, can you get the *outcome* without the *feature*? Yes —
   via explicit, scheduled cross-registry sync.

### Step 8.3 — Apply the fix
```bash
rm acr-georeplication.tf
cp bug-lab/02-fixed-acr-cross-region-sync.tf.txt acr-secondary.tf
terraform apply
chmod +x bug-lab/acr-sync.sh
./bug-lab/acr-sync.sh <primary-acr-name> <secondary-acr-name> dr-ha-spark-demo:1.0.0
```
**Checkpoint:** `az acr repository show --name <secondary-acr-name> --image dr-ha-spark-demo:1.0.0`
returns the image manifest — confirming it landed without ever touching
Premium SKU.

### Step 8.4 — Debrief question (assign as a written answer)
*"The Azure Policy assignment `lab-acr-sku-allowlist` in `policy.tf` would
also have blocked a Premium-SKU ACR outright, before Terraform even needed
to error on the `georeplications` schema conflict. Which failure mode is
more useful to a student — the provider-level SKU-capability error, or the
policy-level denial — and why would a mature platform team want both?"*

*(Expected answer shape: the provider error teaches the underlying Azure
capability model; the policy denial teaches organizational guardrails and
fails faster/earlier, including for changes made outside Terraform entirely,
e.g. via the Portal or `az cli` directly. Both layers exist in real
platforms because they catch different failure paths.)*

---

## 9. Troubleshooting & Debugging Guide

| Symptom | Root cause | Fix |
|---|---|---|
| `Error: A resource with the ID ... already exists` on Key Vault | Previous `destroy` left a soft-deleted vault with the same name | `az keyvault purge --name <kv-name>` then re-apply, or rename via `name_prefix`/`suffix` |
| `RequestDisallowedByPolicy` on a resource you didn't expect | An Azure Policy assignment from `policy.tf` caught a drift between your `.tfvars` and the built-in policy parameters | `az policy assignment list` to see which assignment fired, compare its `parameters` against your `terraform.tfvars` |
| AKS creation stuck > 20 min in `Creating` | Regional capacity constraints on the chosen VM size in a lab-shared subscription | Try `Standard_B2ms` instead of `Standard_D2_v3`, or switch `secondary_region` to `Canada Central`/`Sweden Central` |
| `Error: ... AuthorizationFailed` on `azurerm_role_assignment.*` | Your principal lacks `Microsoft.Authorization/roleAssignments/write` (needs User Access Administrator/Owner, not just Contributor) | Re-check §2; ask lab admin to grant the role |
| `az acr import` (bug-lab) fails with `401 Unauthorized` | The identity running the script isn't `AcrPush`/`Contributor` on the destination registry | `az role assignment create --assignee <your-id> --role AcrPush --scope <secondary-acr-id>` |
| Spark job in AKS can't read/write ADLS Gen2 (`403`) | `azurerm_role_assignment.identity_storage_contributor` targets the region's *own* UAI, but the AKS pod is using the auto-created kubelet identity, not that UAI, unless you've wired Azure AD Workload Identity federation | Follow §7 step 2 exactly; verify with `kubectl describe sa <serviceaccount> -n data-platform-dr` that the workload-identity annotation matches the UAI client ID |
| `terraform destroy` hangs on Recovery Services Vault | RSV refuses deletion while backup items/policies are still associated | `az backup protection disable --backup-item-name ... --delete-backup-data true` for each protected item first, then destroy again |
| Two AKS clusters, one Event Hubs Geo-DR pairing — students assume "replication is now handled" | Conflating Geo-DR (metadata alias) with data replication — see the warning comment in `eventhub.tf` | Re-read §1 of `eventhub.tf`; assign as a discussion question alongside §8.4 |

**General debugging method for this lab (same shape as the app lab):**
1. Reproduce with `terraform plan` before `apply` wherever possible — plan-time
   errors are cheaper to iterate on.
2. Read the *first* error in a multi-error `apply` output — later errors are
   often downstream consequences (e.g. a role assignment failing because its
   scope resource never got created).
3. Check `terraform state list` against your mental model of what should
   exist — a resource silently missing from state (e.g. because a `-target`
   apply skipped it) causes confusing "already exists" or "not found" errors
   on the next full apply.
4. When in doubt, `terraform plan` and read the **diff**, not just the
   resource-count summary — DR infrastructure bugs are frequently "right
   resource, wrong region/SKU/scope," which only shows up in the diff detail.

---

## 10. Teardown (Cost Control)

```bash
# Disable backup protection first (RSV blocks destroy otherwise — see §9)
for RG in $(terraform output -json resource_groups | jq -r '.[]'); do
  VAULT=$(az backup vault list --resource-group "$RG" --query "[0].name" -o tsv)
  [ -n "$VAULT" ] && az backup item list --resource-group "$RG" --vault-name "$VAULT" \
    --query "[].name" -o tsv | while read -r ITEM; do
      az backup protection disable --resource-group "$RG" --vault-name "$VAULT" \
        --item-name "$ITEM" --delete-backup-data true --yes
  done
done

terraform destroy
```
**Checkpoint:** `az group list --query "[?starts_with(name,'rg-drha')].name"`
returns empty.

---

## 11. Assessment Rubric

| Criterion | Weight |
|---|---|
| All resources deploy within the sandbox allow-list (no manual policy overrides needed) | 20% |
| Explains why East US/East US2 aren't an Azure paired region and what that does/doesn't affect | 10% |
| Reproduces the ACR geo-replication bug and articulates the SKU-capability root cause (not just "it errored") | 20% |
| Implements and verifies the `az acr import`-based fix | 20% |
| Distinguishes Event Hubs Geo-DR (metadata) from actual data replication, unprompted | 15% |
| Successfully tears down all resources with no orphaned RSV-protected items | 15% |
