# terraform-dr-ha-lab

Terraform for the **Cross-Region Failover Simulation** infrastructure —
Session 22, Disaster Recovery & High Availability. Provisions two regional
stacks (AKS, ADLS Gen2, Event Hubs, Log Analytics, Recovery Services Vault,
per-region managed identity) plus shared governance (Azure Policy allow-list
enforcement, Key Vault, single-region ACR), entirely within a constrained
lab sandbox's allowed services/SKUs/regions.

**Start here:** [`LAB_GUIDE_TERRAFORM.md`](./LAB_GUIDE_TERRAFORM.md) — full
step-by-step instructions, verification checkpoints, a bug-lab exercise
(`bug-lab/`), and a troubleshooting table.

## File map

```
versions.tf                 Provider/version pinning
variables.tf                All inputs, with validation blocks enforcing the sandbox allow-list
locals.tf                   Region map + naming
network.tf                  Resource groups, VNets, subnets, NSGs
identity.tf                 Per-region user-assigned managed identities
acr.tf                      Single Basic-SKU ACR (primary region) + rationale
keyvault.tf                 Shared Standard-SKU Key Vault + secrets
storage.tf                  ADLS Gen2 (Standard_LRS) per region + Files-share backup target
aks.tf                      AKS clusters per region
eventhub.tf                 Event Hubs namespaces per region + Geo-DR alias
monitoring.tf                Log Analytics + Application Insights per region
backup.tf                   Recovery Services Vault + Azure Files backup policy
rbac.tf                     Role assignments (AcrPull, Storage, Key Vault, Event Hubs)
policy.tf                   Azure Policy: codifies the allow-list as enforced guardrails
outputs.tf                   Everything needed to connect kubectl/Spark/az cli afterwards
terraform.tfvars.example    Copy to terraform.tfvars and fill in subscription_id
bug-lab/                    Intentional ACR geo-replication mistake + correct fix + sync script
```

## Quickstart

```bash
cp terraform.tfvars.example terraform.tfvars   # set subscription_id
terraform init
terraform plan -out=tfplan
terraform apply tfplan
```

Full instructions, verification steps, and the bug-lab exercise are in
`LAB_GUIDE_TERRAFORM.md` — do not skip Phase 2 (policy-first apply) if you
want the guardrails actually enforced.
