############################################
# Azure Container Registry
#
# DELIBERATE ARCHITECTURAL CONSTRAINT: the sandbox only permits the Basic SKU,
# and Basic does NOT support geo-replication (`georeplications` block is a
# Premium-only feature). That means we can only run ONE ACR, in the primary
# region. The secondary-region AKS cluster pulls images cross-region from it
# (see rbac.tf for the AcrPull role assignment granted to BOTH regions'
# kubelet identities).
#
# This is intentionally the same tradeoff pattern as the Spark app's Delta
# replication: a single-region control-plane dependency (here: image
# availability) that must be reasoned about explicitly during a real failover
# — if the PRIMARY region is down, can the SECONDARY region's AKS nodes still
# pull images from an ACR that lives in the now-unavailable region?  (No.)
# See bug-lab/ for the naive "just add georeplications" attempt, why it fails
# on Basic SKU, and the correct fix (scheduled `az acr import` mirroring to a
# second Basic-SKU ACR in the secondary region).
############################################

resource "azurerm_container_registry" "acr" {
  name                = "acr${var.name_prefix}${local.suffix}"
  resource_group_name = azurerm_resource_group.rg["primary"].name
  location            = azurerm_resource_group.rg["primary"].location
  sku                 = var.acr_sku # "Basic" — enforced by variable validation
  admin_enabled       = false       # use AAD/managed-identity auth (AcrPull role), not the admin account
  tags                = local.common_tags
}
