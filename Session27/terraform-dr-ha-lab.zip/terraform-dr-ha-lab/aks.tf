############################################
# AKS Clusters — one per region
############################################

resource "azurerm_kubernetes_cluster" "aks" {
  for_each = local.regions

  name                = "aks-${var.name_prefix}-${each.key}-${local.suffix}"
  location            = azurerm_resource_group.rg[each.key].location
  resource_group_name = azurerm_resource_group.rg[each.key].name
  dns_prefix          = "aks${var.name_prefix}${each.key}${local.suffix}"
  kubernetes_version  = var.kubernetes_version
  sku_tier            = var.aks_sku_tier # "Free" or "Standard" — enforced by variable validation

  default_node_pool {
    name                = "system"
    vm_size             = var.aks_node_vm_size # must be in allowed_aks_vm_sizes
    node_count          = var.aks_node_count
    vnet_subnet_id      = azurerm_subnet.aks_subnet[each.key].id
    os_disk_size_gb     = 64
    type                = "VirtualMachineScaleSets"
    zones               = [] # B/D2 burstable+small SKUs have inconsistent AZ support in some regions; disabled for lab reliability
  }

  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.region_identity[each.key].id]
  }

  network_profile {
    network_plugin    = "azure"
    network_policy    = "azure"
    load_balancer_sku = "standard" # only Standard permitted by sandbox
    service_cidr      = each.key == "primary" ? "10.11.0.0/16" : "10.21.0.0/16"
    dns_service_ip    = each.key == "primary" ? "10.11.0.10" : "10.21.0.10"
  }

  oms_agent {
    log_analytics_workspace_id = azurerm_log_analytics_workspace.law[each.key].id
  }

  azure_policy_enabled = true # enforces the Azure Policy assignments from policy.tf at the AKS admission-control layer too

  tags = local.common_tags

  depends_on = [azurerm_subnet_network_security_group_association.aks_nsg_assoc]
}
