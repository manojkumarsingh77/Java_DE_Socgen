############################################
# Recovery Services Vault — one per region.
#
# Scope of what this actually protects in this lab: the "dr-reports" Azure
# Files share (see storage.tf) that holds the JSON drill reports, via native
# RSV Azure Files backup. This is the "3rd independent copy" leg of the
# 3-2-1 strategy for the artifact that proves your RPO/RTO numbers, distinct
# from the Delta-table replication the Spark app performs on the transaction
# data itself. Azure Site Recovery (VM-level cross-region replication) is
# also hosted by this same resource type but is out of scope here since this
# lab has no IaaS VMs to protect (AKS nodes are managed by the AKS control
# plane, not directly by RSV/ASR).
############################################

resource "azurerm_recovery_services_vault" "rsv" {
  for_each = local.regions

  name                = "rsv-${var.name_prefix}-${each.key}-${local.suffix}"
  location            = azurerm_resource_group.rg[each.key].location
  resource_group_name = azurerm_resource_group.rg[each.key].name
  sku                 = "Standard" # RSV has no other SKU; listed here for clarity/audit
  soft_delete_enabled = true
  storage_mode_type   = "LocallyRedundant" # matches the sandbox's LRS-only storage constraint
  tags                = local.common_tags
}

resource "azurerm_backup_policy_file_share" "daily" {
  for_each = local.regions

  name                = "daily-dr-reports-${each.key}"
  resource_group_name = azurerm_resource_group.rg[each.key].name
  recovery_vault_name = azurerm_recovery_services_vault.rsv[each.key].name

  timezone = "UTC"

  backup {
    frequency = "Daily"
    time      = "23:00"
  }

  retention_daily {
    count = 14
  }
}

resource "azurerm_backup_container_storage_account" "reports_container" {
  for_each = local.regions

  resource_group_name = azurerm_resource_group.rg[each.key].name
  recovery_vault_name  = azurerm_recovery_services_vault.rsv[each.key].name
  storage_account_id   = azurerm_storage_account.files_backup_target[each.key].id
}

resource "azurerm_backup_protected_file_share" "reports_protected" {
  for_each = local.regions

  resource_group_name       = azurerm_resource_group.rg[each.key].name
  recovery_vault_name       = azurerm_recovery_services_vault.rsv[each.key].name
  source_storage_account_id = azurerm_backup_container_storage_account.reports_container[each.key].storage_account_id
  source_file_share_name    = azurerm_storage_share.reports[each.key].name
  backup_policy_id          = azurerm_backup_policy_file_share.daily[each.key].id
}
