#!/usr/bin/env bash
# ============================================================================
# acr-sync.sh — explicit cross-region image replication for Basic-SKU ACR
#
# Run after every push to the primary ACR (wire into your CI/CD pipeline as
# the final step of the image-build job), or on a schedule (Azure Container
# Instances + Logic App timer, or a Kubernetes CronJob in either cluster).
#
# `az acr import` performs a server-side layer copy between registries —
# it does NOT pull the full image to your local Docker daemon and push it
# back up, which matters for both speed and for not needing local disk.
# ============================================================================
set -euo pipefail

PRIMARY_ACR="${1:?Usage: acr-sync.sh <primary-acr-name> <secondary-acr-name> <image:tag>}"
SECONDARY_ACR="${2:?Usage: acr-sync.sh <primary-acr-name> <secondary-acr-name> <image:tag>}"
IMAGE_REF="${3:?Usage: acr-sync.sh <primary-acr-name> <secondary-acr-name> <image:tag>}"

echo "Syncing ${IMAGE_REF} : ${PRIMARY_ACR} -> ${SECONDARY_ACR}"

az acr import \
  --name "${SECONDARY_ACR}" \
  --source "${PRIMARY_ACR}.azurecr.io/${IMAGE_REF}" \
  --image "${IMAGE_REF}" \
  --force

echo "Verifying image landed in secondary registry..."
az acr repository show \
  --name "${SECONDARY_ACR}" \
  --image "${IMAGE_REF}"

echo "Sync complete. Measured RPO for this image = time since last successful CI push"
echo "that triggered this script — track it the same way the Spark app tracks"
echo "transaction replication lag: log a timestamp on send, log a timestamp on"
echo "confirmed landing, and alert if the gap exceeds your image-availability SLA."
