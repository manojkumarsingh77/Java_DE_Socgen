############################################
# Event Hubs — ingestion layer for the retail-banking transaction stream,
# mirroring the "POS → Event Hub → Spark" pattern from the curriculum (Session
# 12) and feeding the cross-region replication demo with a real upstream
# source instead of only synthetic in-process data.
############################################

resource "azurerm_eventhub_namespace" "ehns" {
  for_each = local.regions

  name                = "ehns-${var.name_prefix}-${each.key}-${local.suffix}"
  location            = azurerm_resource_group.rg[each.key].location
  resource_group_name = azurerm_resource_group.rg[each.key].name
  sku                 = var.eventhub_sku # "Basic" or "Standard"
  capacity            = 1
  tags                = local.common_tags
}

# IMPORTANT: entities (eventhub, consumer groups) are created ONLY on the
# PRIMARY namespace. Geo-DR pairing (below) requires the SECONDARY namespace
# to be completely empty at pairing time — it refuses to designate a
# namespace "Secondary" if it already contains entities (409
# MessagingGatewayConflict). Once paired, the primary's entity metadata is
# replicated onto the secondary automatically; you never create it twice.
resource "azurerm_eventhub" "banking_transactions" {
  name                = "banking-transactions"
  namespace_name      = azurerm_eventhub_namespace.ehns["primary"].name
  resource_group_name = azurerm_resource_group.rg["primary"].name
  partition_count     = var.eventhub_partition_count
  message_retention   = 1

  # Must not be created until the secondary namespace is confirmed empty and
  # (if applicable) already paired — see depends_on on the DR config below,
  # and the note there about apply ordering.
  depends_on = [azurerm_eventhub_namespace_disaster_recovery_config.geo_dr]
}

resource "azurerm_eventhub_consumer_group" "spark_dr_consumer" {
  name                = "spark-dr-consumer"
  namespace_name      = azurerm_eventhub_namespace.ehns["primary"].name
  eventhub_name       = azurerm_eventhub.banking_transactions.name
  resource_group_name = azurerm_resource_group.rg["primary"].name
}

############################################
# Geo-DR (namespace alias pairing) — Standard SKU and above only.
#
# IMPORTANT — read before treating this as "cross-region replication solved":
# Event Hubs Geo-DR pairs NAMESPACE METADATA (queues, topics, consumer groups,
# auth rules) so a client can fail over using one stable alias FQDN. It does
# NOT replicate the events/messages themselves — in-flight and already-consumed
# data is not copied to the secondary namespace. Actual event data durability
# across regions still depends on your consumers durably persisting what they
# read (exactly what the Spark ReplicationEngine's commitToPrimary/replicateAsync
# does downstream). Treat Geo-DR here as "clients don't need to be reconfigured
# to find the secondary namespace," not as "the data is safe."
############################################

resource "azurerm_eventhub_namespace_disaster_recovery_config" "geo_dr" {
  count = var.eventhub_sku == "Standard" ? 1 : 0

  name                 = "ehdr-${var.name_prefix}-${local.suffix}"
  resource_group_name  = azurerm_resource_group.rg["primary"].name
  namespace_name       = azurerm_eventhub_namespace.ehns["primary"].name
  partner_namespace_id = azurerm_eventhub_namespace.ehns["secondary"].id
}
