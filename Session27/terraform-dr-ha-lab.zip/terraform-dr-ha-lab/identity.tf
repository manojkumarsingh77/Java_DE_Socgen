resource "azurerm_user_assigned_identity" "region_identity" {
  for_each = local.regions

  name                = "id-${var.name_prefix}-${each.key}-${local.suffix}"
  location            = azurerm_resource_group.rg[each.key].location
  resource_group_name = azurerm_resource_group.rg[each.key].name
  tags                = local.common_tags
}
