data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "kv" {
  name                = "kv-${var.name_prefix}-${local.suffix}"
  location            = azurerm_resource_group.rg["primary"].location
  resource_group_name = azurerm_resource_group.rg["primary"].name
  tenant_id           = data.azurerm_client_config.current.tenant_id
  sku_name            = var.key_vault_sku

  enable_rbac_authorization     = true # RBAC role assignments instead of legacy access policies
  purge_protection_enabled      = false # lab convenience — enable in production
  soft_delete_retention_days    = 7
  public_network_access_enabled = true  # tighten to false + Private Endpoint outside the lab sandbox

  tags = local.common_tags
}

# Grant the deploying principal (you) Key Vault Administrator so you can create
# secrets in the lab steps below.
resource "azurerm_role_assignment" "kv_admin_self" {
  scope                = azurerm_key_vault.kv.id
  role_definition_name = "Key Vault Administrator"
  principal_id         = data.azurerm_client_config.current.object_id
}

# Store each region's storage account connection info and the Event Hubs
# connection string as secrets so the Spark app (or its AKS pod) can read them
# via a CSI Secrets Store driver instead of plaintext env vars / hardcoded values.
resource "azurerm_key_vault_secret" "storage_conn_string" {
  for_each = local.regions

  name         = "storage-conn-${each.key}"
  value        = azurerm_storage_account.adls[each.key].primary_connection_string
  key_vault_id = azurerm_key_vault.kv.id
  depends_on   = [azurerm_role_assignment.kv_admin_self]
}

resource "azurerm_key_vault_secret" "eventhub_conn_string" {
  for_each = local.regions

  name         = "eventhub-conn-${each.key}"
  value        = azurerm_eventhub_namespace.ehns[each.key].default_primary_connection_string
  key_vault_id = azurerm_key_vault.kv.id
  depends_on   = [azurerm_role_assignment.kv_admin_self]
}
