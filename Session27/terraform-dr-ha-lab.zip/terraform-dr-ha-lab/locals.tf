locals {
  # Single source of truth for "which regions does this deployment span" — every
  # per-region resource block (network, aks, storage, eventhub, monitoring, backup)
  # iterates this map with for_each so adding a third region later is a one-line change.
  regions = {
    primary   = var.primary_region
    secondary = var.secondary_region
  }

  # Azure region display name -> short code used in resource names (avoids spaces/
  # special characters, which are illegal in Storage Account / ACR names).
  region_shortcode = {
    "East US"        = "eus"
    "East US2"       = "eus2"
    "Canada Central" = "cac"
    "Sweden Central" = "swc"
  }

  suffix = random_string.suffix.result

  common_tags = merge(var.tags, {
    managed_by = "terraform"
  })

  # NOTE on region pairing (read before you build a DR narrative around this):
  # East US <-> East US2 are NOT an official Azure "paired region" (East US pairs
  # with West US; East US2 pairs with Central US). None of the four sandbox-allowed
  # regions (East US, East US2, Canada Central, Sweden Central) form an official
  # Azure region pair with each other. This is fine for THIS lab — Geo-DR/replication
  # here is deliberately implemented at the application/Terraform layer, not via
  # Azure's paired-region-dependent services (e.g. GRS storage, which isn't allowed
  # anyway) — but flag this explicitly to students: in a real production DR design,
  # region pairing affects planned-maintenance sequencing and some platform DR
  # tooling, and picking non-paired regions is itself an architectural decision
  # that must be justified, not a default.
}

resource "random_string" "suffix" {
  length  = 5
  special = false
  upper   = false
  numeric = true
}
