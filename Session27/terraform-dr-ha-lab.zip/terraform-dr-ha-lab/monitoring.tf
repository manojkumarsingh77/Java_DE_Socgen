resource "azurerm_log_analytics_workspace" "law" {
  for_each = local.regions

  name                = "law-${var.name_prefix}-${each.key}-${local.suffix}"
  location            = azurerm_resource_group.rg[each.key].location
  resource_group_name = azurerm_resource_group.rg[each.key].name
  sku                 = "PerGB2018"
  retention_in_days   = 30
  tags                = local.common_tags
}

resource "azurerm_application_insights" "appi" {
  for_each = local.regions

  name                = "appi-${var.name_prefix}-${each.key}-${local.suffix}"
  location            = azurerm_resource_group.rg[each.key].location
  resource_group_name = azurerm_resource_group.rg[each.key].name
  workspace_id        = azurerm_log_analytics_workspace.law[each.key].id
  application_type    = "java"
  tags                = local.common_tags
}

############################################
# Saved Log Analytics query: surfaces the exact "PRIMARY commit / SECONDARY
# apply" log lines the Spark app emits, filtered per region, so the RPO
# evidence trail lives in Azure Monitor and not only in a JSON file on disk.
############################################

resource "azurerm_log_analytics_saved_search" "replication_lag" {
  for_each = local.regions

  name                       = "dr-replication-lag-${each.key}"
  log_analytics_workspace_id = azurerm_log_analytics_workspace.law[each.key].id
  category                   = "DisasterRecovery"
  display_name               = "Cross-Region Replication Lag (${each.key})"
  query                      = <<-QUERY
    ContainerLogV2
    | where LogMessage has "SECONDARY apply" or LogMessage has "PRIMARY commit"
    | where PodNamespace == "data-platform-dr"
    | project TimeGenerated, LogMessage
    | order by TimeGenerated desc
  QUERY
}
