############################################
# Resource Groups — one per region
############################################

resource "azurerm_resource_group" "rg" {
  for_each = local.regions

  name     = "rg-${var.name_prefix}-${each.key}-${local.suffix}"
  location = each.value
  tags     = local.common_tags
}

############################################
# Virtual Networks — non-overlapping address spaces so a future VNet peering
# or Site-to-Site VPN between regions is possible without renumbering.
############################################

resource "azurerm_virtual_network" "vnet" {
  for_each = local.regions

  name                = "vnet-${var.name_prefix}-${each.key}-${local.suffix}"
  location            = azurerm_resource_group.rg[each.key].location
  resource_group_name = azurerm_resource_group.rg[each.key].name
  address_space       = each.key == "primary" ? ["10.10.0.0/16"] : ["10.20.0.0/16"]
  tags                = local.common_tags
}

resource "azurerm_subnet" "aks_subnet" {
  for_each = local.regions

  name                 = "snet-aks-${each.key}"
  resource_group_name  = azurerm_resource_group.rg[each.key].name
  virtual_network_name = azurerm_virtual_network.vnet[each.key].name
  address_prefixes     = each.key == "primary" ? ["10.10.1.0/24"] : ["10.20.1.0/24"]
}

############################################
# Network Security Groups
############################################

resource "azurerm_network_security_group" "aks_nsg" {
  for_each = local.regions

  name                = "nsg-aks-${each.key}-${local.suffix}"
  location            = azurerm_resource_group.rg[each.key].location
  resource_group_name = azurerm_resource_group.rg[each.key].name
  tags                = local.common_tags

  # Deny all inbound from the internet by default; AKS load balancer rules for
  # any exposed Service type=LoadBalancer are managed separately by the AKS
  # cloud-controller-manager and layer on top of this NSG, not replace it.
  security_rule {
    name                       = "DenyInternetInbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }

  # Allow intra-VNet traffic (node-to-node, node-to-pod-CIDR) required by AKS.
  security_rule {
    name                       = "AllowVnetInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "VirtualNetwork"
  }
}

resource "azurerm_subnet_network_security_group_association" "aks_nsg_assoc" {
  for_each = local.regions

  subnet_id                 = azurerm_subnet.aks_subnet[each.key].id
  network_security_group_id = azurerm_network_security_group.aks_nsg[each.key].id
}
