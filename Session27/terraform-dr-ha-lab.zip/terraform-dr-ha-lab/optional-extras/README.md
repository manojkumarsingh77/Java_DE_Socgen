# optional-extras/

Resources deliberately **excluded from the default `terraform apply`** because
they aren't unambiguously covered by your lab control panel's stated
allow-list, given the real evidence that your tenant enforces an *additional*,
stricter policy (`UnextAzurePolicy_AllowOnlyWhitelistedServices`) that blocked
`ContainerInsights` even though its parent services (AKS, Log Analytics
Workspace) were both explicitly allowed.

| File | What it adds | Why it's optional, not default |
|---|---|---|
| `aks-diagnostic-settings.tf.txt` | AKS control-plane log forwarding (`Microsoft.Insights/diagnosticSettings`) to Log Analytics | Not explicitly named under "Monitoring" (only Log Analytics Workspace + App Insights are) |
| `backup-recovery-services-vault.tf.txt` | A second, non-HNS Standard_LRS storage account + Azure Files share + Recovery Services Vault + backup policy/protection chain, for durably archiving DR drill JSON reports | The storage account isn't ADLS Gen2 (can't be — Azure Files isn't supported on HNS-enabled accounts), and your Storage category is worded specifically "Storage Accounts **(ADLS Gen2)**" |

## How to enable one safely

Don't just drop the file in and run a full `apply`. Validate in isolation
first, so a failure here doesn't block or complicate your core AKS/Event
Hubs/Storage rollout:

```bash
cp optional-extras/aks-diagnostic-settings.tf.txt ./aks-diagnostic-settings.tf
terraform plan -target=azurerm_monitor_diagnostic_setting.aks_control_plane_logs
terraform apply -target=azurerm_monitor_diagnostic_setting.aks_control_plane_logs
```

If it succeeds, it's confirmed compatible with your tenant's actual policy
and you can leave the file in place for future full applies. If it fails
with `RequestDisallowedByPolicy`, remove the file again — you now have a
second confirmed data point on what your tenant's hidden whitelist excludes,
worth reporting to whoever owns it.

Same pattern for the backup file — but note it also needs the RBAC/output
wiring that referenced it before removal; check `git log` / the earlier
version of this project if you want those back exactly as they were.
