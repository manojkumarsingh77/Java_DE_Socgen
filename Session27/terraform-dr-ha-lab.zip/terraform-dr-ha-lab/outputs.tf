output "resource_groups" {
  value = { for k, rg in azurerm_resource_group.rg : k => rg.name }
}

output "aks_cluster_names" {
  value = { for k, c in azurerm_kubernetes_cluster.aks : k => c.name }
}

output "aks_get_credentials_commands" {
  description = "Run these to populate kubeconfig contexts for both clusters."
  value = {
    for k, c in azurerm_kubernetes_cluster.aks :
    k => "az aks get-credentials --resource-group ${azurerm_resource_group.rg[k].name} --name ${c.name} --context ${k}"
  }
}

output "acr_login_server" {
  value = azurerm_container_registry.acr.login_server
}

output "storage_account_names" {
  value = { for k, s in azurerm_storage_account.adls : k => s.name }
}

output "storage_abfss_paths" {
  description = "Paste these into AppConfig for a cloud-backed run of the Spark demo."
  value = {
    primary   = "abfss://ledger@${azurerm_storage_account.adls["primary"].name}.dfs.core.windows.net/primary_txn_ledger"
    secondary = "abfss://ledger@${azurerm_storage_account.adls["secondary"].name}.dfs.core.windows.net/secondary_txn_ledger"
  }
}

output "eventhub_namespace_fqdns" {
  value = { for k, ns in azurerm_eventhub_namespace.ehns : k => ns.name }
}

output "key_vault_name" {
  value = azurerm_key_vault.kv.name
}

output "recovery_services_vault_names" {
  value = { for k, v in azurerm_recovery_services_vault.rsv : k => v.name }
}

output "log_analytics_workspace_ids" {
  value = { for k, w in azurerm_log_analytics_workspace.law : k => w.workspace_id }
}
