############################################
# Governance-as-code: rather than relying on students to remember the lab's
# allow-list from a document, codify it as Azure Policy so a non-compliant
# `terraform apply` (or a manual `az` / Portal change afterwards) is denied
# by the platform itself, not just caught in code review.
#
# APPLY ORDER MATTERS: run this file's resources before (or in the same
# apply as, understanding the race described in LAB_GUIDE_TERRAFORM.md §4)
# the resources in network.tf/aks.tf/etc. See the lab guide for the
# recommended two-phase `-target` apply.
############################################

data "azurerm_subscription" "current" {}

# ---- Built-in: Allowed locations -------------------------------------------------
resource "azurerm_subscription_policy_assignment" "allowed_locations" {
  name                 = "lab-allowed-locations"
  display_name         = "Lab sandbox: allowed regions only"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"
  subscription_id      = data.azurerm_subscription.current.id

  parameters = jsonencode({
    listOfAllowedLocations = {
      value = var.allowed_regions
    }
  })
}

# ---- Built-in: Allowed virtual machine SKUs ---------------------------------------
resource "azurerm_subscription_policy_assignment" "allowed_vm_skus" {
  name                 = "lab-allowed-vm-skus"
  display_name         = "Lab sandbox: allowed AKS node VM sizes only"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/cccc23c7-8427-4f53-ad12-b6a63eb452b3"
  subscription_id      = data.azurerm_subscription.current.id

  parameters = jsonencode({
    listOfAllowedSKUs = {
      value = var.allowed_aks_vm_sizes
    }
  })
}

# ---- Custom: Allowed Storage Account SKU (Standard_LRS only) ---------------------
resource "azurerm_policy_definition" "storage_sku_allowlist" {
  name         = "lab-storage-sku-allowlist"
  policy_type  = "Custom"
  mode         = "Indexed"
  display_name = "Lab sandbox: Storage Accounts must use Standard_LRS"
  description  = "Denies creation of any Storage Account whose SKU is not Standard_LRS, per the lab control panel's allow-list."

  policy_rule = jsonencode({
    if = {
      allOf = [
        { field = "type", equals = "Microsoft.Storage/storageAccounts" },
        { not = { field = "Microsoft.Storage/storageAccounts/sku.name", equals = "Standard_LRS" } }
      ]
    }
    then = { effect = "deny" }
  })
}

resource "azurerm_subscription_policy_assignment" "storage_sku_allowlist" {
  name                 = "lab-storage-sku-allowlist"
  display_name         = "Lab sandbox: Storage Accounts must use Standard_LRS"
  policy_definition_id = azurerm_policy_definition.storage_sku_allowlist.id
  subscription_id      = data.azurerm_subscription.current.id
}

# ---- Custom: Allowed ACR SKU (Basic only) -----------------------------------------
resource "azurerm_policy_definition" "acr_sku_allowlist" {
  name         = "lab-acr-sku-allowlist"
  policy_type  = "Custom"
  mode         = "Indexed"
  display_name = "Lab sandbox: Container Registries must use Basic SKU"
  description  = "Denies creation of any ACR whose SKU is not Basic, per the lab control panel's allow-list. Also serves as the guardrail that turns the bug-lab/ georeplication mistake into an immediate, explicit denial instead of a confusing provider error."

  policy_rule = jsonencode({
    if = {
      allOf = [
        { field = "type", equals = "Microsoft.ContainerRegistry/registries" },
        { not = { field = "Microsoft.ContainerRegistry/registries/sku.name", equals = "Basic" } }
      ]
    }
    then = { effect = "deny" }
  })
}

resource "azurerm_subscription_policy_assignment" "acr_sku_allowlist" {
  name                 = "lab-acr-sku-allowlist"
  display_name         = "Lab sandbox: Container Registries must use Basic SKU"
  policy_definition_id = azurerm_policy_definition.acr_sku_allowlist.id
  subscription_id      = data.azurerm_subscription.current.id
}

# ---- Custom: Require the module/course tags on everything (governance hygiene) ---
resource "azurerm_policy_definition" "require_module_tag" {
  name         = "lab-require-module-tag"
  policy_type  = "Custom"
  mode         = "Indexed"
  display_name = "Lab sandbox: resources must carry a 'module' tag"
  description  = "Ensures every resource created for this lab is attributable to the disaster-recovery-ha module for cost/quota review."

  policy_rule = jsonencode({
    if = {
      field = "tags['module']"
      exists = "false"
    }
    then = { effect = "audit" } # audit, not deny — new resource types the policy doesn't recognize shouldn't hard-fail the lab
  })
}

resource "azurerm_subscription_policy_assignment" "require_module_tag" {
  name                 = "lab-require-module-tag"
  display_name         = "Lab sandbox: resources must carry a 'module' tag"
  policy_definition_id = azurerm_policy_definition.require_module_tag.id
  subscription_id      = data.azurerm_subscription.current.id
}
