############################################
# AKS kubelet identity -> AcrPull on the (single, primary-region) ACR.
# Both regions' clusters need this, since only one ACR exists (see acr.tf).
############################################

resource "azurerm_role_assignment" "aks_acr_pull" {
  for_each = local.regions

  scope                            = azurerm_container_registry.acr.id
  role_definition_name             = "AcrPull"
  principal_id                     = azurerm_kubernetes_cluster.aks[each.key].kubelet_identity[0].object_id
  skip_service_principal_aad_check = true
}

############################################
# Per-region user-assigned identity -> Storage Blob Data Contributor on its
# OWN region's ADLS Gen2 account (least privilege: primary's identity cannot
# write to secondary's storage directly — replication happens through the
# Spark app's own Delta writes, authenticated separately per target).
############################################

resource "azurerm_role_assignment" "identity_storage_contributor" {
  for_each = local.regions

  scope                = azurerm_storage_account.adls[each.key].id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_user_assigned_identity.region_identity[each.key].principal_id
}

# The PRIMARY region's workload identity additionally needs write access to
# the SECONDARY storage account, because it is the one performing the
# cross-region replication write (see ReplicationEngine.replicateAsync).
resource "azurerm_role_assignment" "primary_identity_can_replicate_to_secondary" {
  scope                = azurerm_storage_account.adls["secondary"].id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id          = azurerm_user_assigned_identity.region_identity["primary"].principal_id
}

############################################
# Per-region identity -> Key Vault Secrets User on the shared vault.
############################################

resource "azurerm_role_assignment" "identity_kv_secrets_user" {
  for_each = local.regions

  scope                = azurerm_key_vault.kv.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_user_assigned_identity.region_identity[each.key].principal_id
}

############################################
# AKS kubelet identity -> Event Hubs Data Receiver/Sender on its own region's
# namespace (POS -> Event Hub -> Spark ingestion path).
############################################

resource "azurerm_role_assignment" "aks_eventhub_sender" {
  for_each = local.regions

  scope                = azurerm_eventhub_namespace.ehns[each.key].id
  role_definition_name = "Azure Event Hubs Data Sender"
  principal_id         = azurerm_kubernetes_cluster.aks[each.key].kubelet_identity[0].object_id
}

resource "azurerm_role_assignment" "aks_eventhub_receiver" {
  for_each = local.regions

  scope                = azurerm_eventhub_namespace.ehns[each.key].id
  role_definition_name = "Azure Event Hubs Data Receiver"
  principal_id         = azurerm_kubernetes_cluster.aks[each.key].kubelet_identity[0].object_id
}
