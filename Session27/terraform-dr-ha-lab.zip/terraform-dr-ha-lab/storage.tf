############################################
# Storage Accounts (ADLS Gen2) — one per region, Standard_LRS only.
#
# These are the real-infrastructure counterpart of the local Delta paths used
# in the IntelliJ demo (primary_txn_ledger / secondary_txn_ledger). Point the
# Spark app's AppConfig at:
#   abfss://ledger@<primary storage account>.dfs.core.windows.net/primary_txn_ledger
#   abfss://ledger@<secondary storage account>.dfs.core.windows.net/secondary_txn_ledger
############################################

resource "azurerm_storage_account" "adls" {
  for_each = local.regions

  # Storage Account names have a hard 24-character cap — use the short region
  # code (eus/eus2/cac/swc), not the full "primary"/"secondary" word, so the
  # name stays well under the limit regardless of name_prefix length.
  name                = "st${var.name_prefix}${local.region_shortcode[each.value]}${local.suffix}"
  resource_group_name = azurerm_resource_group.rg[each.key].name
  location            = azurerm_resource_group.rg[each.key].location

  account_tier             = "Standard"
  account_replication_type = var.storage_replication_type # "LRS" — enforced by variable validation
  account_kind             = "StorageV2"
  is_hns_enabled            = true # Hierarchical namespace = ADLS Gen2, required for Delta Lake on abfss://

  min_tls_version                = "TLS1_2"
  allow_nested_items_to_be_public = false

  tags = local.common_tags
}

resource "azurerm_storage_container" "ledger" {
  for_each = local.regions

  name                  = "ledger"
  storage_account_name  = azurerm_storage_account.adls[each.key].name
  container_access_type = "private"
}

# NOTE: a second, non-HNS "Azure Files backup target" storage account +
# Recovery Services Vault backup chain (for durably archiving DR drill JSON
# reports) previously lived here. Moved to optional-extras/ — see that
# folder's README. Reason: this sandbox's Storage allow-list is worded
# specifically as "Storage Accounts (ADLS Gen2)", and a plain non-HNS
# Standard_LRS account (required because Azure Files isn't supported on
# HNS-enabled accounts) is an ambiguous fit against that wording. Validate
# it in isolation before adding it back to the default apply.
