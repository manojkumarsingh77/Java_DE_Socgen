############################################
# Core / identity
############################################

variable "subscription_id" {
  description = "Azure subscription ID for the lab sandbox."
  type        = string
}

variable "name_prefix" {
  description = "Short prefix applied to every resource name (letters/numbers only, <= 8 chars recommended)."
  type        = string
  default     = "drha"

  validation {
    condition     = can(regex("^[a-z0-9]{2,8}$", var.name_prefix))
    error_message = "name_prefix must be 2-8 lowercase alphanumeric characters (Storage Account / ACR naming rules are the binding constraint)."
  }
}

variable "tags" {
  description = "Common tags applied to every resource."
  type        = map(string)
  default = {
    module      = "disaster-recovery-ha"
    course      = "java-spark-data-engineering"
    provisioner = "terraform"
  }
}

############################################
# Region allow-list (sandbox guardrail)
############################################

variable "allowed_regions" {
  description = "Regions permitted by the lab control panel. Do not edit unless your sandbox policy changes."
  type        = list(string)
  default     = ["East US", "East US2", "Canada Central", "Sweden Central"]
}

variable "primary_region" {
  description = "Primary (active) region — must be a member of allowed_regions."
  type        = string
  default     = "East US"

  validation {
    condition     = contains(["East US", "East US2", "Canada Central", "Sweden Central"], var.primary_region)
    error_message = "primary_region must be one of the sandbox's allowed regions: East US, East US2, Canada Central, Sweden Central."
  }
}

variable "secondary_region" {
  description = "Secondary (DR) region — must be a member of allowed_regions and different from primary_region."
  type        = string
  default     = "East US2"

  validation {
    condition     = contains(["East US", "East US2", "Canada Central", "Sweden Central"], var.secondary_region)
    error_message = "secondary_region must be one of the sandbox's allowed regions: East US, East US2, Canada Central, Sweden Central."
  }
}

############################################
# AKS
############################################

variable "allowed_aks_vm_sizes" {
  description = "VM sizes permitted for AKS node pools by the lab control panel."
  type        = list(string)
  default     = ["Standard_B2ms", "Standard_B4ms", "Standard_D2_v3", "Standard_D2S_v3", "Standard_DS1_v2"]
}

variable "aks_node_vm_size" {
  description = "VM size for the AKS default node pool in both regions."
  type        = string
  default     = "Standard_D2_v3"

  validation {
    condition     = contains(["Standard_B2ms", "Standard_B4ms", "Standard_D2_v3", "Standard_D2S_v3", "Standard_DS1_v2"], var.aks_node_vm_size)
    error_message = "aks_node_vm_size must be one of the sandbox's allowed VM sizes."
  }
}

variable "aks_sku_tier" {
  description = "AKS control-plane pricing tier."
  type        = string
  default     = "Standard"

  validation {
    condition     = contains(["Free", "Standard"], var.aks_sku_tier)
    error_message = "aks_sku_tier must be Free or Standard per the sandbox allow-list."
  }
}

variable "aks_node_count" {
  description = "Fixed node count per region (kept small deliberately for B/D2-class quota)."
  type        = number
  default     = 2
}

variable "kubernetes_version" {
  description = "AKS Kubernetes version. Leave null to use the region's current default."
  type        = string
  default     = null
}

############################################
# ACR
############################################

variable "acr_sku" {
  description = "Azure Container Registry SKU."
  type        = string
  default     = "Basic"

  validation {
    condition     = var.acr_sku == "Basic"
    error_message = "Only the Basic SKU is permitted by the sandbox — note this SKU does NOT support geo-replication (see bug-lab/)."
  }
}

############################################
# Storage (ADLS Gen2)
############################################

variable "storage_replication_type" {
  description = "Storage account replication type."
  type        = string
  default     = "LRS"

  validation {
    condition     = var.storage_replication_type == "LRS"
    error_message = "Only Standard_LRS is permitted by the sandbox — no GRS/RA-GRS. Cross-region durability must be achieved at the application layer (see Spark ReplicationEngine) or via Recovery Services Vault backup, not storage-native geo-replication."
  }
}

############################################
# Event Hubs
############################################

variable "eventhub_sku" {
  description = "Event Hubs namespace SKU."
  type        = string
  default     = "Standard"

  validation {
    condition     = contains(["Basic", "Standard"], var.eventhub_sku)
    error_message = "eventhub_sku must be Basic or Standard per the sandbox allow-list. Geo-DR (namespace alias) pairing requires Standard or higher."
  }
}

variable "eventhub_partition_count" {
  type    = number
  default = 4
}

############################################
# Key Vault
############################################

variable "key_vault_sku" {
  type    = string
  default = "standard"

  validation {
    condition     = var.key_vault_sku == "standard"
    error_message = "Only the Standard Key Vault SKU is permitted by the sandbox."
  }
}
