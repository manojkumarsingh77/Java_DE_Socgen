terraform {
  required_version = ">= 1.7.0, < 2.0.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"          # AzureRM v3 syntax used throughout this project.
                                     # If you use provider v4.x, review the v3->v4 upgrade
                                     # guide first — storage account replication attribute
                                     # names and a few identity block shapes changed.
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }
}

provider "azurerm" {
  features {
    key_vault {
      # Lab convenience: purge on `terraform destroy` instead of leaving a
      # soft-deleted vault behind that blocks re-creating the same name.
      # DO NOT set this in a real production subscription.
      purge_soft_delete_on_destroy    = true
      recover_soft_deleted_key_vaults = true
    }
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
  }
  subscription_id = var.subscription_id
}
