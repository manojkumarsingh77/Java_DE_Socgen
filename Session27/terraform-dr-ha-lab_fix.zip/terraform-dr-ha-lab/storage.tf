############################################
# Storage Accounts (ADLS Gen2) — one per region, Standard_LRS only.
#
# These are the real-infrastructure counterpart of the local Delta paths used
# in the IntelliJ demo (primary_txn_ledger / secondary_txn_ledger). Point the
# Spark app's AppConfig at:
#   abfss://ledger@<primary storage account>.dfs.core.windows.net/primary_txn_ledger
#   abfss://ledger@<secondary storage account>.dfs.core.windows.net/secondary_txn_ledger
############################################

resource "azurerm_storage_account" "adls" {
  for_each = local.regions

  # Storage Account names have a hard 24-character cap — use the short region
  # code (eus/eus2/cac/swc), not the full "primary"/"secondary" word, so the
  # name stays well under the limit regardless of name_prefix length.
  name                = "st${var.name_prefix}${local.region_shortcode[each.value]}${local.suffix}"
  resource_group_name = azurerm_resource_group.rg[each.key].name
  location            = azurerm_resource_group.rg[each.key].location

  account_tier             = "Standard"
  account_replication_type = var.storage_replication_type # "LRS" — enforced by variable validation
  account_kind             = "StorageV2"
  is_hns_enabled            = true # Hierarchical namespace = ADLS Gen2, required for Delta Lake on abfss://

  min_tls_version                = "TLS1_2"
  allow_nested_items_to_be_public = false

  tags = local.common_tags
}

resource "azurerm_storage_container" "ledger" {
  for_each = local.regions

  name                  = "ledger"
  storage_account_name  = azurerm_storage_account.adls[each.key].name
  container_access_type = "private"
}

# A regular Azure Files share, used specifically as the Recovery Services Vault
# backup target in backup.tf — RSV backs up Azure Files shares natively; it does
# NOT back up ADLS Gen2 blob/DFS data (that needs the separate Backup vault /
# Microsoft.DataProtection resource type, which is outside this sandbox's
# allow-list).
#
# IMPORTANT: Azure Files shares are NOT supported on storage accounts with
# the hierarchical namespace (HNS) enabled — i.e. NOT on the ADLS Gen2 account
# above. This is a genuine Azure platform constraint, not a lab restriction,
# so we provision a second, plain (non-HNS) Standard_LRS storage account per
# region purely to host the Files share that Recovery Services Vault protects,
# holding the DR drill JSON reports as a durable, vault-backed artifact.
resource "azurerm_storage_account" "files_backup_target" {
  for_each = local.regions

  name                = "stf${var.name_prefix}${local.region_shortcode[each.value]}${local.suffix}"
  resource_group_name = azurerm_resource_group.rg[each.key].name
  location            = azurerm_resource_group.rg[each.key].location

  account_tier             = "Standard"
  account_replication_type = var.storage_replication_type # "LRS"
  account_kind             = "StorageV2"
  is_hns_enabled            = false # must be false for Azure Files support

  min_tls_version                 = "TLS1_2"
  allow_nested_items_to_be_public = false

  tags = local.common_tags
}

resource "azurerm_storage_share" "reports" {
  for_each = local.regions

  name                 = "dr-reports"
  storage_account_name = azurerm_storage_account.files_backup_target[each.key].name
  quota                = 10
}
